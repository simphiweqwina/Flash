'use strict';

const { createApp } = require('./app');

const { app, config } = createApp();

const server = app.listen(config.port, () => {
  console.log(`PayPoint API listening on http://localhost:${config.port}`);
  console.log(`  OpenAPI spec:  http://localhost:${config.port}/openapi.json`);
  console.log(`  Health check:  http://localhost:${config.port}/health`);
  console.log(
    `  Config: tokenTtl=${config.tokenTtlSeconds}s loginRateLimit=${config.loginRateLimitMax}/${config.loginRateLimitWindowMs}ms ` +
      `purchaseDelay=${config.purchaseMinDelayMs}-${config.purchaseMaxDelayMs}ms chaosRate=${config.chaosFailureRate}`,
  );
});

const shutdown = (signal) => {
  console.log(`${signal} received, shutting down`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

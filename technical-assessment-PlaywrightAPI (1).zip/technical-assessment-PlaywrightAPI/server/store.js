'use strict';

const crypto = require('node:crypto');
const { SEED_PASSWORD, seedUsers, seedProducts, defaultFeatures } = require('./seed');

const hashPassword = (password) => crypto.createHash('sha256').update(password).digest('hex');
const now = () => new Date().toISOString();

/**
 * In-memory data store. All state is lost when the process stops or /__test__/reset is called.
 */
function createStore() {
  const state = {};
  const timers = new Set();

  function reset() {
    for (const t of timers) clearTimeout(t);
    timers.clear();

    state.users = new Map(); // id -> user
    state.usernames = new Map(); // username -> id
    state.accessTokens = new Map(); // token -> { userId, expiresAt }
    state.refreshTokens = new Map(); // token -> { userId, expiresAt }
    state.products = new Map(); // id -> product
    state.purchases = new Map(); // id -> purchase
    state.ledger = new Map(); // userId -> entry[]
    state.idempotency = new Map(); // `${userId}:${key}` -> { fingerprint, purchaseId }
    state.loginAttempts = new Map(); // ip -> { windowStart, count }
    state.features = { ...defaultFeatures };

    for (const u of seedUsers) createUser({ ...u, password: SEED_PASSWORD });
    for (const p of seedProducts) {
      const id = crypto.randomUUID();
      state.products.set(id, { id, ...structuredClone(p) });
    }
  }

  function createUser({ username, password, displayName, balanceCents = 0, locked = false }) {
    const id = crypto.randomUUID();
    const user = {
      id,
      username,
      displayName: displayName ?? username,
      passwordHash: hashPassword(password),
      locked,
      balanceCents: 0,
      createdAt: now(),
    };
    state.users.set(id, user);
    state.usernames.set(username, id);
    state.ledger.set(id, []);
    if (balanceCents > 0) addLedgerEntry(user, 'TOPUP', balanceCents, 'Opening balance');
    return user;
  }

  function addLedgerEntry(user, type, amountCents, reference) {
    user.balanceCents += amountCents;
    const entry = {
      id: crypto.randomUUID(),
      type,
      amountCents,
      balanceAfterCents: user.balanceCents,
      reference,
      createdAt: now(),
    };
    state.ledger.get(user.id).unshift(entry);
    return entry;
  }

  function schedule(fn, ms) {
    const t = setTimeout(() => {
      timers.delete(t);
      fn();
    }, ms);
    t.unref?.();
    timers.add(t);
  }

  reset();

  return {
    state,
    reset,
    createUser,
    addLedgerEntry,
    schedule,
    hashPassword,
    findUserByUsername: (username) => state.users.get(state.usernames.get(username)),
  };
}

module.exports = { createStore };

'use strict';

const crypto = require('node:crypto');
const { ApiError } = require('./errors');

/** Echo X-Request-Id if supplied, otherwise generate one. */
function requestId() {
  return (req, res, next) => {
    const incoming = req.get('X-Request-Id');
    req.id = incoming && /^[\w.-]{1,128}$/.test(incoming) ? incoming : crypto.randomUUID();
    res.set('X-Request-Id', req.id);
    next();
  };
}

function requestLogger(config) {
  return (req, res, next) => {
    if (!config.logRequests) return next();
    const start = process.hrtime.bigint();
    res.on('finish', () => {
      const ms = Number(process.hrtime.bigint() - start) / 1e6;
      console.log(`${req.method} ${req.originalUrl} ${res.statusCode} ${ms.toFixed(1)}ms rid=${req.id}`);
    });
    next();
  };
}

/** Reject bodies that are not JSON on write methods. */
function requireJson() {
  return (req, _res, next) => {
    const hasBody = Number(req.get('Content-Length') || 0) > 0 || req.get('Transfer-Encoding');
    if (['POST', 'PUT', 'PATCH'].includes(req.method) && hasBody && !req.is('application/json')) {
      return next(new ApiError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Request body must be application/json.'));
    }
    next();
  };
}

/**
 * Simulates transient infrastructure failures (e.g. a load balancer or upstream blip).
 * A failed request has NO side effects - it is rejected before reaching the handler.
 */
function chaos(config) {
  return (_req, _res, next) => {
    if (config.chaosFailureRate > 0 && Math.random() < config.chaosFailureRate) {
      return next(
        new ApiError(503, 'SERVICE_UNAVAILABLE', 'Service temporarily unavailable. Please retry.', undefined, {
          'Retry-After': '1',
        }),
      );
    }
    next();
  };
}

/** Bearer token authentication. Sets req.user. */
function authenticate(store) {
  return (req, _res, next) => {
    const header = req.get('Authorization') || '';
    const match = /^Bearer\s+(\S+)$/i.exec(header);
    const wwwAuth = { 'WWW-Authenticate': 'Bearer realm="paypoint"' };
    if (!match) {
      return next(new ApiError(401, 'UNAUTHENTICATED', 'Missing or malformed Authorization header.', undefined, wwwAuth));
    }
    const session = store.state.accessTokens.get(match[1]);
    if (!session) {
      return next(new ApiError(401, 'INVALID_TOKEN', 'Access token is invalid or has been revoked.', undefined, wwwAuth));
    }
    if (session.expiresAt <= Date.now()) {
      return next(new ApiError(401, 'TOKEN_EXPIRED', 'Access token has expired.', undefined, wwwAuth));
    }
    const user = store.state.users.get(session.userId);
    if (!user) {
      return next(new ApiError(401, 'INVALID_TOKEN', 'Access token is invalid or has been revoked.', undefined, wwwAuth));
    }
    req.user = user;
    req.accessToken = match[1];
    next();
  };
}

/** Fixed-window rate limiter keyed by client IP. */
function loginRateLimit(store, config) {
  return (req, _res, next) => {
    const key = req.ip;
    const nowMs = Date.now();
    let bucket = store.state.loginAttempts.get(key);
    if (!bucket || nowMs - bucket.windowStart >= config.loginRateLimitWindowMs) {
      bucket = { windowStart: nowMs, count: 0 };
      store.state.loginAttempts.set(key, bucket);
    }
    bucket.count += 1;
    if (bucket.count > config.loginRateLimitMax) {
      const retryAfter = Math.ceil((bucket.windowStart + config.loginRateLimitWindowMs - nowMs) / 1000);
      return next(
        new ApiError(429, 'RATE_LIMITED', 'Too many login attempts. Please try again later.', undefined, {
          'Retry-After': String(Math.max(retryAfter, 1)),
        }),
      );
    }
    next();
  };
}

function notFound() {
  return (req, _res, next) => next(new ApiError(404, 'NOT_FOUND', `No route for ${req.method} ${req.path}.`));
}

// eslint-disable-next-line no-unused-vars
function errorHandler() {
  return (err, req, res, _next) => {
    let apiError = err;
    if (err?.type === 'entity.parse.failed') {
      apiError = new ApiError(400, 'MALFORMED_JSON', 'Request body is not valid JSON.');
    } else if (err?.type === 'entity.too.large') {
      apiError = new ApiError(413, 'PAYLOAD_TOO_LARGE', 'Request body is too large.');
    } else if (!(err instanceof ApiError)) {
      console.error(err);
      apiError = new ApiError(500, 'INTERNAL_ERROR', 'An unexpected error occurred.');
    }
    if (apiError.headers) res.set(apiError.headers);
    res.status(apiError.status).json({
      error: {
        code: apiError.code,
        message: apiError.message,
        ...(apiError.details ? { details: apiError.details } : {}),
        requestId: req.id,
      },
    });
  };
}

module.exports = {
  requestId,
  requestLogger,
  requireJson,
  chaos,
  authenticate,
  loginRateLimit,
  notFound,
  errorHandler,
};

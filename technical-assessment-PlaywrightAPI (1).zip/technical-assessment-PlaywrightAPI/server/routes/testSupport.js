'use strict';

const crypto = require('node:crypto');
const express = require('express');
const { ApiError, validationError } = require('../errors');
const { isPlainObject } = require('../validation');

/**
 * Test-support ("backdoor") endpoints. These exist to make the system testable and
 * would never be deployed to production. All require the X-Test-Support-Key header.
 */
function testSupportRouter(store, config) {
  const router = express.Router();

  router.use((req, _res, next) => {
    if (req.get('X-Test-Support-Key') !== config.testSupportKey) {
      return next(new ApiError(403, 'FORBIDDEN', 'A valid X-Test-Support-Key header is required.'));
    }
    next();
  });

  // Reset ALL state (users, tokens, purchases, rate limits, feature flags) back to seed data.
  router.post('/reset', (_req, res) => {
    store.reset();
    res.status(204).end();
  });

  // Create a fresh, isolated user. Returns credentials - you still need to log in.
  router.post('/users', (req, res) => {
    const body = req.body ?? {};
    if (!isPlainObject(body)) throw validationError([{ field: 'body', issue: 'must be a JSON object' }]);
    const { balanceCents = 0, locked = false, displayName } = body;
    const details = [];
    if (!Number.isInteger(balanceCents) || balanceCents < 0 || balanceCents > 10_000_000) {
      details.push({ field: 'balanceCents', issue: 'must be an integer between 0 and 10000000' });
    }
    if (typeof locked !== 'boolean') details.push({ field: 'locked', issue: 'must be a boolean' });
    if (displayName !== undefined && (typeof displayName !== 'string' || !displayName.trim())) {
      details.push({ field: 'displayName', issue: 'must be a non-empty string' });
    }
    if (details.length) throw validationError(details);

    const username = `user_${crypto.randomBytes(6).toString('hex')}`;
    const password = `Pw-${crypto.randomBytes(9).toString('base64url')}`;
    const user = store.createUser({ username, password, displayName, balanceCents, locked });
    res.status(201).json({ id: user.id, username, password, balanceCents: user.balanceCents, locked });
  });

  // Force an access token to expire immediately (to test expiry/refresh handling).
  router.post('/tokens/expire', (req, res) => {
    const token = req.body?.accessToken;
    if (typeof token !== 'string' || !token) throw validationError([{ field: 'accessToken', issue: 'is required' }]);
    const session = store.state.accessTokens.get(token);
    if (!session) throw new ApiError(404, 'TOKEN_NOT_FOUND', 'Unknown access token.');
    session.expiresAt = Date.now() - 1;
    res.status(204).end();
  });

  // Toggle feature flags. NOTE: flags are GLOBAL - they affect every user/test.
  router.put('/features', (req, res) => {
    const body = req.body;
    if (!isPlainObject(body)) throw validationError([{ field: 'body', issue: 'must be a JSON object' }]);
    const details = [];
    for (const [k, v] of Object.entries(body)) {
      if (!(k in store.state.features)) details.push({ field: k, issue: 'unknown feature flag' });
      else if (typeof v !== 'boolean') details.push({ field: k, issue: 'must be a boolean' });
    }
    if (details.length) throw validationError(details);
    Object.assign(store.state.features, body);
    res.json({ ...store.state.features });
  });

  return router;
}

module.exports = { testSupportRouter };

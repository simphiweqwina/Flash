'use strict';

const express = require('express');
const { ApiError } = require('../errors');
const { parsePagination, paginate, enumParam, throwIfDetails } = require('../validation');

const CATEGORIES = ['AIRTIME', 'DATA', 'VOUCHER', 'ELECTRICITY'];
const SORTS = ['name', '-name', 'price', '-price'];

/** Fixed products sort by price, variable products by their minimum amount. */
const sortPrice = (p) => (p.pricing.type === 'FIXED' ? p.pricing.priceCents : p.pricing.minCents);

const isVisible = (store, product) => product.category !== 'ELECTRICITY' || store.state.features.electricity;

function productsRouter(store) {
  const router = express.Router();

  router.get('/', (req, res) => {
    const { page, pageSize, details } = parsePagination(req.query);
    const category = enumParam(req.query, 'category', CATEGORIES, details);
    const sort = enumParam(req.query, 'sort', SORTS, details) ?? 'name';
    const provider = req.query.provider;
    if (provider !== undefined && (typeof provider !== 'string' || !provider)) {
      details.push({ field: 'provider', issue: 'must be a non-empty string' });
    }
    throwIfDetails(details);

    let items = [...store.state.products.values()].filter((p) => p.active && isVisible(store, p));
    if (category) items = items.filter((p) => p.category === category);
    if (provider) items = items.filter((p) => p.provider === provider.toUpperCase());

    const desc = sort.startsWith('-');
    const key = sort.replace('-', '');
    items.sort((a, b) => {
      const cmp = key === 'price' ? sortPrice(a) - sortPrice(b) || a.name.localeCompare(b.name) : a.name.localeCompare(b.name);
      return desc ? -cmp : cmp;
    });

    res.json(paginate(items, page, pageSize));
  });

  router.get('/:id', (req, res) => {
    const product = store.state.products.get(req.params.id);
    if (!product || !isVisible(store, product)) {
      throw new ApiError(404, 'PRODUCT_NOT_FOUND', 'Product not found.');
    }
    res.json(product);
  });

  return router;
}

module.exports = { productsRouter, isVisible };

'use strict';

const crypto = require('node:crypto');
const express = require('express');
const { ApiError, validationError } = require('../errors');
const { isPlainObject } = require('../validation');
const { authenticate, loginRateLimit } = require('../middleware');

const newToken = () => crypto.randomBytes(32).toString('base64url');

function issueTokens(store, config, userId) {
  const accessToken = newToken();
  const refreshToken = newToken();
  const nowMs = Date.now();
  store.state.accessTokens.set(accessToken, { userId, expiresAt: nowMs + config.tokenTtlSeconds * 1000 });
  store.state.refreshTokens.set(refreshToken, { userId, expiresAt: nowMs + config.refreshTokenTtlSeconds * 1000 });
  return { accessToken, tokenType: 'Bearer', expiresIn: config.tokenTtlSeconds, refreshToken };
}

function authRouter(store, config) {
  const router = express.Router();

  router.post('/login', loginRateLimit(store, config), (req, res) => {
    const body = req.body;
    const details = [];
    if (!isPlainObject(body)) throw validationError([{ field: 'body', issue: 'must be a JSON object' }]);
    if (typeof body.username !== 'string' || !body.username.trim()) details.push({ field: 'username', issue: 'is required' });
    if (typeof body.password !== 'string' || !body.password) details.push({ field: 'password', issue: 'is required' });
    if (details.length) throw validationError(details);

    const user = store.findUserByUsername(body.username);
    if (!user || user.passwordHash !== store.hashPassword(body.password)) {
      throw new ApiError(401, 'INVALID_CREDENTIALS', 'Username or password is incorrect.');
    }
    if (user.locked) throw new ApiError(423, 'ACCOUNT_LOCKED', 'This account is locked. Contact support.');

    res.status(200).json(issueTokens(store, config, user.id));
  });

  router.post('/refresh', (req, res) => {
    const body = req.body;
    if (!isPlainObject(body) || typeof body.refreshToken !== 'string' || !body.refreshToken) {
      throw validationError([{ field: 'refreshToken', issue: 'is required' }]);
    }
    const session = store.state.refreshTokens.get(body.refreshToken);
    // Refresh tokens are single-use (rotation): consume it whatever the outcome.
    store.state.refreshTokens.delete(body.refreshToken);
    if (!session || session.expiresAt <= Date.now() || !store.state.users.has(session.userId)) {
      throw new ApiError(401, 'INVALID_REFRESH_TOKEN', 'Refresh token is invalid, expired or already used.');
    }
    const user = store.state.users.get(session.userId);
    if (user.locked) throw new ApiError(423, 'ACCOUNT_LOCKED', 'This account is locked. Contact support.');
    res.status(200).json(issueTokens(store, config, session.userId));
  });

  router.post('/logout', authenticate(store), (req, res) => {
    store.state.accessTokens.delete(req.accessToken);
    res.status(204).end();
  });

  return router;
}

module.exports = { authRouter };

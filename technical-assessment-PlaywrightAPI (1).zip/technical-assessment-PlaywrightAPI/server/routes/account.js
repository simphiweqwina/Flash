'use strict';

const express = require('express');
const crypto = require('node:crypto');
const { validationError } = require('../errors');
const { isPlainObject, parsePagination, paginate, enumParam, throwIfDetails } = require('../validation');

const TOPUP_MIN = 1_000;
const TOPUP_MAX = 500_000;

function accountRouter(store) {
  const router = express.Router();

  router.get('/me', (req, res) => {
    const { id, username, displayName, createdAt } = req.user;
    res.json({ id, username, displayName, createdAt });
  });

  router.get('/wallet', (req, res) => {
    res.json({ balanceCents: req.user.balanceCents, currency: 'ZAR' });
  });

  router.post('/wallet/topups', (req, res) => {
    const body = req.body;
    if (!isPlainObject(body)) throw validationError([{ field: 'body', issue: 'must be a JSON object' }]);
    const { amountCents } = body;
    if (!Number.isInteger(amountCents)) {
      throw validationError([{ field: 'amountCents', issue: 'must be an integer' }]);
    }
    if (amountCents < TOPUP_MIN || amountCents > TOPUP_MAX) {
      throw validationError([{ field: 'amountCents', issue: `must be between ${TOPUP_MIN} and ${TOPUP_MAX}` }]);
    }
    const reference = `TOPUP-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const entry = store.addLedgerEntry(req.user, 'TOPUP', amountCents, reference);
    res.status(201).json({ transactionId: entry.id, amountCents, balanceCents: req.user.balanceCents, currency: 'ZAR' });
  });

  router.get('/wallet/transactions', (req, res) => {
    const { page, pageSize, details } = parsePagination(req.query);
    const type = enumParam(req.query, 'type', ['TOPUP', 'PURCHASE', 'REFUND'], details);
    throwIfDetails(details);
    let items = store.state.ledger.get(req.user.id);
    if (type) items = items.filter((e) => e.type === type);
    res.json(paginate(items, page, pageSize));
  });

  return router;
}

module.exports = { accountRouter };

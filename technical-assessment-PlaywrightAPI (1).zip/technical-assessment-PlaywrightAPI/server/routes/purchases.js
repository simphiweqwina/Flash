'use strict';

const crypto = require('node:crypto');
const express = require('express');
const { ApiError, validationError } = require('../errors');
const {
  isPlainObject,
  parsePagination,
  paginate,
  enumParam,
  throwIfDetails,
  normaliseMsisdn,
  isMeterNumber,
} = require('../validation');
const { isVisible } = require('./products');

const STATUSES = ['PENDING', 'SUCCESSFUL', 'FAILED'];
const CATEGORIES = ['AIRTIME', 'DATA', 'VOUCHER', 'ELECTRICITY'];
const IDEMPOTENCY_KEY_PATTERN = /^[A-Za-z0-9_-]{8,64}$/;

const randomDigits = (n) => Array.from({ length: n }, () => crypto.randomInt(10)).join('');
const nowIso = () => new Date().toISOString();

/** Public representation of a purchase (internal fields stripped). */
function toDto(p) {
  const { userId, fingerprint, ...dto } = p; // eslint-disable-line no-unused-vars
  return dto;
}

function buildFulfilment(purchase) {
  switch (purchase.product.category) {
    case 'VOUCHER': {
      const expires = new Date();
      expires.setFullYear(expires.getFullYear() + 1);
      return { type: 'PIN', pin: randomDigits(16), serial: `VCH${randomDigits(10)}`, expiresAt: expires.toISOString() };
    }
    case 'ELECTRICITY':
      return {
        type: 'ELECTRICITY_TOKEN',
        token: randomDigits(20),
        units: Math.round((purchase.amountCents / 100 / 2.85) * 10) / 10, // kWh at a fictional R2.85/kWh
      };
    default:
      return { type: 'DIRECT_TOPUP' };
  }
}

/**
 * Simulated upstream provider. Outcome is deterministic based on the recipient identifier:
 *   ends in 0000 -> provider rejects (FAILED, wallet refunded)
 *   ends in 9999 -> slow provider (completes after SLOW_PROVIDER_DELAY_MS)
 *   anything else -> SUCCESSFUL after a random delay
 */
function scheduleFulfilment(store, config, purchase, recipientId) {
  const fail = recipientId.endsWith('0000');
  const slow = recipientId.endsWith('9999');
  const delay = slow
    ? config.slowProviderDelayMs
    : crypto.randomInt(config.purchaseMinDelayMs, Math.max(config.purchaseMinDelayMs, config.purchaseMaxDelayMs) + 1);

  store.schedule(() => {
    const user = store.state.users.get(purchase.userId);
    if (!user || purchase.status !== 'PENDING') return;
    const ts = nowIso();
    if (fail) {
      purchase.status = 'FAILED';
      purchase.failureReason = 'PROVIDER_REJECTED';
      store.addLedgerEntry(user, 'REFUND', purchase.amountCents, purchase.id);
    } else {
      purchase.status = 'SUCCESSFUL';
      purchase.fulfilment = buildFulfilment(purchase);
    }
    purchase.updatedAt = ts;
    purchase.completedAt = ts;
  }, delay);
}

function purchasesRouter(store, config) {
  const router = express.Router();

  router.post('/', (req, res) => {
    // 1. Idempotency key
    const key = req.get('Idempotency-Key');
    if (!key) throw new ApiError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'The Idempotency-Key header is required.');
    if (!IDEMPOTENCY_KEY_PATTERN.test(key)) {
      throw validationError([{ field: 'Idempotency-Key', issue: 'must be 8-64 characters of [A-Za-z0-9_-]' }]);
    }

    // 2. Body shape
    const body = req.body;
    if (!isPlainObject(body)) throw validationError([{ field: 'body', issue: 'must be a JSON object' }]);
    const { productId, recipient, amountCents } = body;

    // 3. Replay / conflict detection
    const fingerprint = JSON.stringify([
      productId ?? null,
      recipient?.msisdn ?? null,
      recipient?.meterNumber ?? null,
      amountCents ?? null,
    ]);
    const idemKey = `${req.user.id}:${key}`;
    const previous = store.state.idempotency.get(idemKey);
    if (previous) {
      if (previous.fingerprint !== fingerprint) {
        throw new ApiError(409, 'IDEMPOTENCY_KEY_REUSED', 'Idempotency-Key was already used with a different request body.');
      }
      const original = store.state.purchases.get(previous.purchaseId);
      res.set('Idempotent-Replayed', 'true');
      res.set('Location', `/purchases/${original.id}`);
      return res.status(200).json(toDto(original));
    }

    // 4. Field validation
    const details = [];
    if (typeof productId !== 'string' || !productId) details.push({ field: 'productId', issue: 'is required' });
    if (!isPlainObject(recipient)) details.push({ field: 'recipient', issue: 'must be an object' });
    if (amountCents !== undefined && !Number.isInteger(amountCents)) {
      details.push({ field: 'amountCents', issue: 'must be an integer' });
    }
    throwIfDetails(details);

    // 5. Product checks
    const product = store.state.products.get(productId);
    if (!product) throw new ApiError(422, 'PRODUCT_NOT_FOUND', 'The referenced product does not exist.');
    if (!isVisible(store, product)) {
      throw new ApiError(422, 'FEATURE_DISABLED', `${product.category} purchases are currently disabled.`);
    }
    if (!product.active) throw new ApiError(422, 'PRODUCT_UNAVAILABLE', 'This product is no longer available.');

    // 6. Recipient
    let normalisedRecipient;
    let recipientId;
    if (product.recipientType === 'MSISDN') {
      const msisdn = normaliseMsisdn(recipient.msisdn);
      if (!msisdn) {
        throw validationError([{ field: 'recipient.msisdn', issue: 'must be a valid South African mobile number' }]);
      }
      normalisedRecipient = { msisdn };
      recipientId = msisdn;
    } else {
      if (!isMeterNumber(recipient.meterNumber)) {
        throw validationError([{ field: 'recipient.meterNumber', issue: 'must be exactly 11 digits' }]);
      }
      normalisedRecipient = { meterNumber: recipient.meterNumber };
      recipientId = recipient.meterNumber;
    }

    // 7. Amount
    let chargeCents;
    if (product.pricing.type === 'FIXED') {
      if (amountCents !== undefined) {
        throw validationError([{ field: 'amountCents', issue: 'must not be supplied for fixed-price products' }]);
      }
      chargeCents = product.pricing.priceCents;
    } else {
      const { minCents, maxCents, stepCents } = product.pricing;
      if (amountCents === undefined) {
        throw validationError([{ field: 'amountCents', issue: 'is required for variable-price products' }]);
      }
      if (amountCents < minCents || amountCents > maxCents) {
        throw validationError([{ field: 'amountCents', issue: `must be between ${minCents} and ${maxCents}` }]);
      }
      if (amountCents % stepCents !== 0) {
        throw validationError([{ field: 'amountCents', issue: `must be a multiple of ${stepCents}` }]);
      }
      chargeCents = amountCents;
    }

    // 8. Funds (check + debit are atomic: Node handles this synchronously)
    if (req.user.balanceCents < chargeCents) {
      throw new ApiError(422, 'INSUFFICIENT_FUNDS', 'Wallet balance is insufficient for this purchase.');
    }

    const ts = nowIso();
    const purchase = {
      id: crypto.randomUUID(),
      userId: req.user.id,
      fingerprint,
      status: 'PENDING',
      product: { id: product.id, sku: product.sku, name: product.name, category: product.category, provider: product.provider },
      recipient: normalisedRecipient,
      amountCents: chargeCents,
      currency: 'ZAR',
      failureReason: null,
      fulfilment: null,
      createdAt: ts,
      updatedAt: ts,
      completedAt: null,
    };
    store.addLedgerEntry(req.user, 'PURCHASE', -chargeCents, purchase.id);
    store.state.purchases.set(purchase.id, purchase);
    store.state.idempotency.set(idemKey, { fingerprint, purchaseId: purchase.id });
    scheduleFulfilment(store, config, purchase, recipientId);

    res.set('Location', `/purchases/${purchase.id}`);
    res.status(202).json(toDto(purchase));
  });

  router.get('/', (req, res) => {
    const { page, pageSize, details } = parsePagination(req.query);
    const status = enumParam(req.query, 'status', STATUSES, details);
    const category = enumParam(req.query, 'category', CATEGORIES, details);
    throwIfDetails(details);

    // Map preserves insertion order; reverse for newest first.
    let items = [...store.state.purchases.values()].reverse().filter((p) => p.userId === req.user.id);
    if (status) items = items.filter((p) => p.status === status);
    if (category) items = items.filter((p) => p.product.category === category);

    const result = paginate(items, page, pageSize);
    res.json({ ...result, items: result.items.map(toDto) });
  });

  router.get('/:id', (req, res) => {
    const purchase = store.state.purchases.get(req.params.id);
    // Other users' purchases are reported as not found (no resource enumeration).
    if (!purchase || purchase.userId !== req.user.id) {
      throw new ApiError(404, 'PURCHASE_NOT_FOUND', 'Purchase not found.');
    }
    res.json(toDto(purchase));
  });

  return router;
}

module.exports = { purchasesRouter };

'use strict';

const { validationError } = require('./errors');

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

/** Parse page/pageSize query params. Throws a 400 on invalid input. */
function parsePagination(query, { defaultPageSize = 10, maxPageSize = 50 } = {}) {
  const details = [];
  const parseIntParam = (name, fallback, min, max) => {
    const raw = query[name];
    if (raw === undefined) return fallback;
    if (typeof raw !== 'string' || !/^\d+$/.test(raw)) {
      details.push({ field: name, issue: 'must be a positive integer' });
      return fallback;
    }
    const n = Number(raw);
    if (n < min || n > max) details.push({ field: name, issue: `must be between ${min} and ${max}` });
    return n;
  };
  const page = parseIntParam('page', 1, 1, Number.MAX_SAFE_INTEGER);
  const pageSize = parseIntParam('pageSize', defaultPageSize, 1, maxPageSize);
  return { page, pageSize, details };
}

function paginate(items, page, pageSize) {
  const total = items.length;
  return {
    items: items.slice((page - 1) * pageSize, page * pageSize),
    page,
    pageSize,
    total,
    totalPages: Math.ceil(total / pageSize),
  };
}

function enumParam(query, name, allowed, details) {
  const raw = query[name];
  if (raw === undefined) return undefined;
  if (typeof raw !== 'string' || !allowed.includes(raw)) {
    details.push({ field: name, issue: `must be one of: ${allowed.join(', ')}` });
    return undefined;
  }
  return raw;
}

function throwIfDetails(details) {
  if (details.length) throw validationError(details);
}

/** South African mobile number: 0XXXXXXXXX or +27XXXXXXXXX (mobile prefixes 6, 7, 8). Returns E.164 or null. */
function normaliseMsisdn(value) {
  if (typeof value !== 'string') return null;
  const m = /^(?:\+27|0)([678]\d{8})$/.exec(value.trim());
  return m ? `+27${m[1]}` : null;
}

const isMeterNumber = (value) => typeof value === 'string' && /^\d{11}$/.test(value);

module.exports = { isPlainObject, parsePagination, paginate, enumParam, throwIfDetails, normaliseMsisdn, isMeterNumber };

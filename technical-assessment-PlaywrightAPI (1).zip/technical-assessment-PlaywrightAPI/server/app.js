'use strict';

const express = require('express');
const { loadConfig } = require('./config');
const { createStore } = require('./store');
const mw = require('./middleware');
const { authRouter } = require('./routes/auth');
const { productsRouter } = require('./routes/products');
const { accountRouter } = require('./routes/account');
const { purchasesRouter } = require('./routes/purchases');
const { testSupportRouter } = require('./routes/testSupport');
const { spec } = require('./openapi');
const { version } = require('../package.json');

function createApp(config = loadConfig()) {
  const store = createStore();
  const app = express();
  const startedAt = Date.now();

  app.disable('x-powered-by');
  app.set('trust proxy', false);

  app.use(mw.requestId());
  app.use(mw.requestLogger(config));
  app.use(mw.requireJson());
  app.use(express.json({ limit: '32kb' }));

  // --- Infrastructure endpoints (never affected by chaos) ---
  app.get('/health', (_req, res) => {
    res.json({ status: 'ok', version, uptimeSeconds: Math.round((Date.now() - startedAt) / 1000) });
  });
  app.get('/openapi.json', (_req, res) => res.json(spec));
  app.use('/__test__', testSupportRouter(store, config));

  // --- Business endpoints (subject to transient 503s) ---
  const chaos = mw.chaos(config);
  const auth = mw.authenticate(store);

  app.get('/config/features', chaos, (_req, res) => res.json({ ...store.state.features }));
  app.use('/auth', chaos, authRouter(store, config));
  app.use('/products', chaos, productsRouter(store));
  app.use('/purchases', chaos, auth, purchasesRouter(store, config));
  app.use(['/me', '/wallet'], chaos, auth);
  app.use(accountRouter(store));

  app.use(mw.notFound());
  app.use(mw.errorHandler());

  return { app, store, config };
}

module.exports = { createApp };

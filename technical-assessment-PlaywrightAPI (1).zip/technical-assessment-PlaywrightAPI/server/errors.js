'use strict';

class ApiError extends Error {
  /**
   * @param {number} status HTTP status code
   * @param {string} code Stable, machine-readable error code
   * @param {string} message Human-readable message
   * @param {Array<{field: string, issue: string}>} [details]
   * @param {Record<string, string>} [headers] Extra response headers
   */
  constructor(status, code, message, details, headers) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
    this.headers = headers;
  }
}

const validationError = (details) =>
  new ApiError(400, 'VALIDATION_ERROR', 'One or more fields are invalid.', details);

module.exports = { ApiError, validationError };

'use strict';

const num = (value, fallback) => (value === undefined || value === '' ? fallback : Number(value));
const bool = (value, fallback) => (value === undefined || value === '' ? fallback : value === 'true');

/**
 * Server configuration. Every value can be overridden with an environment variable,
 * but candidates' test suites are expected to pass against the DEFAULTS.
 */
function loadConfig(env = process.env) {
  return {
    port: num(env.PORT, 3000),
    logRequests: bool(env.LOG_REQUESTS, true),

    // Auth
    tokenTtlSeconds: num(env.TOKEN_TTL_SECONDS, 300),
    refreshTokenTtlSeconds: num(env.REFRESH_TOKEN_TTL_SECONDS, 3600),

    // Login rate limiting (fixed window, per client IP)
    loginRateLimitMax: num(env.LOGIN_RATE_LIMIT_MAX, 20),
    loginRateLimitWindowMs: num(env.LOGIN_RATE_LIMIT_WINDOW_MS, 60_000),

    // Simulated upstream provider latency for purchase fulfilment
    purchaseMinDelayMs: num(env.PURCHASE_MIN_DELAY_MS, 500),
    purchaseMaxDelayMs: num(env.PURCHASE_MAX_DELAY_MS, 4000),
    slowProviderDelayMs: num(env.SLOW_PROVIDER_DELAY_MS, 8000),

    // Probability (0..1) that a business endpoint returns a transient 503
    chaosFailureRate: num(env.CHAOS_FAILURE_RATE, 0.02),

    // Shared secret for /__test__ endpoints (sent as X-Test-Support-Key)
    testSupportKey: env.TEST_SUPPORT_KEY ?? 'qa-assessment-key',
  };
}

module.exports = { loadConfig };

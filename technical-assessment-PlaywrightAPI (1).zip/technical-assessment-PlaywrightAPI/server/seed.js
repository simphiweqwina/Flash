'use strict';

/**
 * Seed data. Product IDs are generated at start-up (and on every reset), so they
 * are NOT stable between runs - the `sku` is the stable business identifier.
 */

const SEED_PASSWORD = 'Passw0rd!';

const seedUsers = [
  { username: 'alice', displayName: 'Alice Mokoena', balanceCents: 50_000, locked: false },
  { username: 'bob', displayName: 'Bob van Wyk', balanceCents: 0, locked: false },
  { username: 'carol', displayName: 'Carol Naidoo', balanceCents: 10_000, locked: true },
];

const airtime = (provider, name) => ({
  sku: `AIR-${provider}`,
  name: `${name} Airtime`,
  provider,
  category: 'AIRTIME',
  recipientType: 'MSISDN',
  pricing: { type: 'VARIABLE', minCents: 500, maxCents: 100_000, stepCents: 100 },
  active: true,
});

const data = (sku, provider, name, priceCents, active = true) => ({
  sku,
  name,
  provider,
  category: 'DATA',
  recipientType: 'MSISDN',
  pricing: { type: 'FIXED', priceCents },
  active,
});

const voucher = (sku, name, priceCents) => ({
  sku,
  name,
  provider: 'GENERIC',
  category: 'VOUCHER',
  recipientType: 'MSISDN',
  pricing: { type: 'FIXED', priceCents },
  active: true,
});

const electricity = (sku, provider, name) => ({
  sku,
  name,
  provider,
  category: 'ELECTRICITY',
  recipientType: 'METER',
  pricing: { type: 'VARIABLE', minCents: 2_000, maxCents: 300_000, stepCents: 100 },
  active: true,
});

const seedProducts = [
  airtime('VODACOM', 'Vodacom'),
  airtime('MTN', 'MTN'),
  airtime('CELLC', 'Cell C'),
  airtime('TELKOM', 'Telkom'),
  data('DATA-VODACOM-1GB', 'VODACOM', 'Vodacom 1GB Data (30 days)', 9_900),
  data('DATA-VODACOM-3GB', 'VODACOM', 'Vodacom 3GB Data (30 days)', 19_900),
  data('DATA-MTN-1GB', 'MTN', 'MTN 1GB Data (30 days)', 9_900),
  data('DATA-MTN-5GB', 'MTN', 'MTN 5GB Data (30 days)', 24_900),
  data('DATA-MTN-500MB-LEGACY', 'MTN', 'MTN 500MB Data (legacy)', 5_900, false),
  data('DATA-CELLC-2GB', 'CELLC', 'Cell C 2GB Data (30 days)', 14_900),
  data('DATA-TELKOM-10GB', 'TELKOM', 'Telkom 10GB Data (30 days)', 29_900),
  voucher('VOUCHER-GIFT-50', 'Gift Voucher R50', 5_000),
  voucher('VOUCHER-GIFT-100', 'Gift Voucher R100', 10_000),
  voucher('VOUCHER-GIFT-250', 'Gift Voucher R250', 25_000),
  electricity('ELEC-ESKOM', 'ESKOM', 'Eskom Prepaid Electricity'),
  electricity('ELEC-CITYPOWER', 'CITYPOWER', 'City Power Prepaid Electricity'),
  electricity('ELEC-CAPETOWN', 'CAPETOWN', 'City of Cape Town Prepaid Electricity'),
];

const defaultFeatures = { electricity: true };

module.exports = { SEED_PASSWORD, seedUsers, seedProducts, defaultFeatures };

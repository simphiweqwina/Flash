'use strict';

/**
 * OpenAPI 3.1 contract for the PayPoint API. Served at GET /openapi.json.
 */

const ref = (name) => ({ $ref: `#/components/schemas/${name}` });
const json = (schema) => ({ 'application/json': { schema } });
const errorResponse = (description) => ({ description, content: json(ref('Error')) });
const bearer = [{ bearerAuth: [] }];
const testKey = [{ testSupportKey: [] }];

const pageParams = [
  { name: 'page', in: 'query', schema: { type: 'integer', minimum: 1, default: 1 } },
  { name: 'pageSize', in: 'query', schema: { type: 'integer', minimum: 1, maximum: 50, default: 10 } },
];

const paged = (itemSchema) => ({
  type: 'object',
  additionalProperties: false,
  required: ['items', 'page', 'pageSize', 'total', 'totalPages'],
  properties: {
    items: { type: 'array', items: itemSchema },
    page: { type: 'integer', minimum: 1 },
    pageSize: { type: 'integer', minimum: 1, maximum: 50 },
    total: { type: 'integer', minimum: 0 },
    totalPages: { type: 'integer', minimum: 0 },
  },
});

const common = {
  400: errorResponse('Validation error (VALIDATION_ERROR, MALFORMED_JSON)'),
  401: errorResponse('UNAUTHENTICATED, INVALID_TOKEN or TOKEN_EXPIRED'),
  415: errorResponse('UNSUPPORTED_MEDIA_TYPE'),
  503: errorResponse('SERVICE_UNAVAILABLE - transient, retry after the Retry-After header'),
};

const spec = {
  openapi: '3.1.0',
  info: {
    title: 'PayPoint API',
    version: '1.0.0',
    description:
      'Fictional prepaid value-added-services API (airtime, data, vouchers, electricity) used as the system under test ' +
      'for the QA Automation Architect assessment. All monetary values are integers in cents (ZAR).',
  },
  servers: [{ url: 'http://localhost:3000' }],
  tags: [
    { name: 'Meta' },
    { name: 'Auth' },
    { name: 'Catalogue' },
    { name: 'Account' },
    { name: 'Purchases' },
    { name: 'Test support', description: 'Testability hooks. Require X-Test-Support-Key.' },
  ],
  paths: {
    '/health': {
      get: {
        tags: ['Meta'],
        summary: 'Liveness probe',
        responses: { 200: { description: 'OK', content: json(ref('Health')) } },
      },
    },
    '/config/features': {
      get: {
        tags: ['Meta'],
        summary: 'Current feature flags',
        responses: { 200: { description: 'OK', content: json(ref('Features')) }, 503: common[503] },
      },
    },
    '/auth/login': {
      post: {
        tags: ['Auth'],
        summary: 'Exchange credentials for tokens',
        description: 'Rate limited per client IP (default 20 requests / 60s window, all attempts count).',
        requestBody: { required: true, content: json(ref('LoginRequest')) },
        responses: {
          200: { description: 'Authenticated', content: json(ref('TokenResponse')) },
          400: common[400],
          401: errorResponse('INVALID_CREDENTIALS'),
          415: common[415],
          423: errorResponse('ACCOUNT_LOCKED'),
          429: errorResponse('RATE_LIMITED - see Retry-After header'),
          503: common[503],
        },
      },
    },
    '/auth/refresh': {
      post: {
        tags: ['Auth'],
        summary: 'Rotate tokens using a refresh token (single use)',
        requestBody: { required: true, content: json(ref('RefreshRequest')) },
        responses: {
          200: { description: 'New token pair', content: json(ref('TokenResponse')) },
          400: common[400],
          401: errorResponse('INVALID_REFRESH_TOKEN'),
          423: errorResponse('ACCOUNT_LOCKED'),
          503: common[503],
        },
      },
    },
    '/auth/logout': {
      post: {
        tags: ['Auth'],
        summary: 'Revoke the current access token',
        security: bearer,
        responses: { 204: { description: 'Revoked' }, 401: common[401], 503: common[503] },
      },
    },
    '/products': {
      get: {
        tags: ['Catalogue'],
        summary: 'List active products (public)',
        parameters: [
          ...pageParams,
          { name: 'category', in: 'query', schema: ref('Category') },
          { name: 'provider', in: 'query', schema: { type: 'string' }, description: 'Case-insensitive provider code' },
          { name: 'sort', in: 'query', schema: { type: 'string', enum: ['name', '-name', 'price', '-price'], default: 'name' } },
        ],
        responses: {
          200: { description: 'Page of products', content: json(paged(ref('Product'))) },
          400: common[400],
          503: common[503],
        },
      },
    },
    '/products/{id}': {
      get: {
        tags: ['Catalogue'],
        summary: 'Get a product by id (includes inactive products)',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          200: { description: 'Product', content: json(ref('Product')) },
          404: errorResponse('PRODUCT_NOT_FOUND'),
          503: common[503],
        },
      },
    },
    '/me': {
      get: {
        tags: ['Account'],
        security: bearer,
        summary: 'Current user profile',
        responses: { 200: { description: 'OK', content: json(ref('Me')) }, 401: common[401], 503: common[503] },
      },
    },
    '/wallet': {
      get: {
        tags: ['Account'],
        security: bearer,
        summary: 'Wallet balance',
        responses: { 200: { description: 'OK', content: json(ref('Wallet')) }, 401: common[401], 503: common[503] },
      },
    },
    '/wallet/topups': {
      post: {
        tags: ['Account'],
        security: bearer,
        summary: 'Top up wallet (R10.00 - R5 000.00)',
        requestBody: { required: true, content: json(ref('TopupRequest')) },
        responses: {
          201: { description: 'Topped up', content: json(ref('TopupResponse')) },
          400: common[400],
          401: common[401],
          415: common[415],
          503: common[503],
        },
      },
    },
    '/wallet/transactions': {
      get: {
        tags: ['Account'],
        security: bearer,
        summary: 'Wallet ledger, newest first',
        parameters: [...pageParams, { name: 'type', in: 'query', schema: { type: 'string', enum: ['TOPUP', 'PURCHASE', 'REFUND'] } }],
        responses: {
          200: { description: 'Page of ledger entries', content: json(paged(ref('LedgerEntry'))) },
          400: common[400],
          401: common[401],
          503: common[503],
        },
      },
    },
    '/purchases': {
      post: {
        tags: ['Purchases'],
        security: bearer,
        summary: 'Create a purchase (asynchronous)',
        description:
          'Debits the wallet immediately and returns 202 with status PENDING. Poll GET /purchases/{id} until the ' +
          'status is SUCCESSFUL or FAILED. Failed purchases are refunded (REFUND ledger entry). ' +
          'Replaying the same Idempotency-Key with the same body returns the original purchase (200, ' +
          'Idempotent-Replayed: true); with a different body returns 409.',
        parameters: [
          {
            name: 'Idempotency-Key',
            in: 'header',
            required: true,
            schema: { type: 'string', pattern: '^[A-Za-z0-9_-]{8,64}$' },
          },
        ],
        requestBody: { required: true, content: json(ref('PurchaseRequest')) },
        responses: {
          202: {
            description: 'Accepted - PENDING',
            headers: { Location: { schema: { type: 'string' } } },
            content: json(ref('Purchase')),
          },
          200: {
            description: 'Idempotent replay of an earlier request',
            headers: { 'Idempotent-Replayed': { schema: { type: 'string', enum: ['true'] } } },
            content: json(ref('Purchase')),
          },
          400: errorResponse('VALIDATION_ERROR, MALFORMED_JSON or IDEMPOTENCY_KEY_REQUIRED'),
          401: common[401],
          409: errorResponse('IDEMPOTENCY_KEY_REUSED'),
          415: common[415],
          422: errorResponse('PRODUCT_NOT_FOUND, PRODUCT_UNAVAILABLE, FEATURE_DISABLED or INSUFFICIENT_FUNDS'),
          503: common[503],
        },
      },
      get: {
        tags: ['Purchases'],
        security: bearer,
        summary: "List the caller's purchases, newest first",
        parameters: [
          ...pageParams,
          { name: 'status', in: 'query', schema: ref('PurchaseStatus') },
          { name: 'category', in: 'query', schema: ref('Category') },
        ],
        responses: {
          200: { description: 'Page of purchases', content: json(paged(ref('Purchase'))) },
          400: common[400],
          401: common[401],
          503: common[503],
        },
      },
    },
    '/purchases/{id}': {
      get: {
        tags: ['Purchases'],
        security: bearer,
        summary: 'Get a purchase (only your own)',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: {
          200: { description: 'Purchase', content: json(ref('Purchase')) },
          401: common[401],
          404: errorResponse('PURCHASE_NOT_FOUND'),
          503: common[503],
        },
      },
    },
    '/__test__/reset': {
      post: {
        tags: ['Test support'],
        security: testKey,
        summary: 'Reset ALL server state to seed data (global!)',
        responses: { 204: { description: 'Reset' }, 403: errorResponse('FORBIDDEN') },
      },
    },
    '/__test__/users': {
      post: {
        tags: ['Test support'],
        security: testKey,
        summary: 'Create an isolated user with a random username/password',
        requestBody: { required: false, content: json(ref('CreateTestUserRequest')) },
        responses: {
          201: { description: 'Created', content: json(ref('TestUser')) },
          400: common[400],
          403: errorResponse('FORBIDDEN'),
        },
      },
    },
    '/__test__/tokens/expire': {
      post: {
        tags: ['Test support'],
        security: testKey,
        summary: 'Force an access token to expire now',
        requestBody: {
          required: true,
          content: json({ type: 'object', required: ['accessToken'], properties: { accessToken: { type: 'string' } } }),
        },
        responses: {
          204: { description: 'Expired' },
          400: common[400],
          403: errorResponse('FORBIDDEN'),
          404: errorResponse('TOKEN_NOT_FOUND'),
        },
      },
    },
    '/__test__/features': {
      put: {
        tags: ['Test support'],
        security: testKey,
        summary: 'Toggle feature flags (global!)',
        requestBody: { required: true, content: json(ref('Features')) },
        responses: {
          200: { description: 'Updated flags', content: json(ref('Features')) },
          400: common[400],
          403: errorResponse('FORBIDDEN'),
        },
      },
    },
    '/openapi.json': {
      get: { tags: ['Meta'], summary: 'This document', responses: { 200: { description: 'OpenAPI document' } } },
    },
  },
  components: {
    securitySchemes: {
      bearerAuth: { type: 'http', scheme: 'bearer' },
      testSupportKey: { type: 'apiKey', in: 'header', name: 'X-Test-Support-Key' },
    },
    schemas: {
      Error: {
        type: 'object',
        additionalProperties: false,
        required: ['error'],
        properties: {
          error: {
            type: 'object',
            additionalProperties: false,
            required: ['code', 'message', 'requestId'],
            properties: {
              code: { type: 'string' },
              message: { type: 'string' },
              requestId: { type: 'string' },
              details: {
                type: 'array',
                items: {
                  type: 'object',
                  additionalProperties: false,
                  required: ['field', 'issue'],
                  properties: { field: { type: 'string' }, issue: { type: 'string' } },
                },
              },
            },
          },
        },
      },
      Health: {
        type: 'object',
        additionalProperties: false,
        required: ['status', 'version', 'uptimeSeconds'],
        properties: { status: { type: 'string', enum: ['ok'] }, version: { type: 'string' }, uptimeSeconds: { type: 'number' } },
      },
      Features: {
        type: 'object',
        additionalProperties: false,
        properties: { electricity: { type: 'boolean' } },
      },
      LoginRequest: {
        type: 'object',
        required: ['username', 'password'],
        properties: { username: { type: 'string' }, password: { type: 'string' } },
      },
      RefreshRequest: {
        type: 'object',
        required: ['refreshToken'],
        properties: { refreshToken: { type: 'string' } },
      },
      TokenResponse: {
        type: 'object',
        additionalProperties: false,
        required: ['accessToken', 'tokenType', 'expiresIn', 'refreshToken'],
        properties: {
          accessToken: { type: 'string' },
          tokenType: { type: 'string', enum: ['Bearer'] },
          expiresIn: { type: 'integer', description: 'Seconds until the access token expires' },
          refreshToken: { type: 'string' },
        },
      },
      Category: { type: 'string', enum: ['AIRTIME', 'DATA', 'VOUCHER', 'ELECTRICITY'] },
      PurchaseStatus: { type: 'string', enum: ['PENDING', 'SUCCESSFUL', 'FAILED'] },
      Pricing: {
        oneOf: [
          {
            type: 'object',
            additionalProperties: false,
            required: ['type', 'priceCents'],
            properties: { type: { type: 'string', enum: ['FIXED'] }, priceCents: { type: 'integer', minimum: 0 } },
          },
          {
            type: 'object',
            additionalProperties: false,
            required: ['type', 'minCents', 'maxCents', 'stepCents'],
            properties: {
              type: { type: 'string', enum: ['VARIABLE'] },
              minCents: { type: 'integer', minimum: 0 },
              maxCents: { type: 'integer', minimum: 0 },
              stepCents: { type: 'integer', minimum: 1 },
            },
          },
        ],
      },
      Product: {
        type: 'object',
        additionalProperties: false,
        required: ['id', 'sku', 'name', 'provider', 'category', 'recipientType', 'pricing', 'active'],
        properties: {
          id: { type: 'string', format: 'uuid', description: 'Regenerated on every server start/reset' },
          sku: { type: 'string', description: 'Stable business identifier' },
          name: { type: 'string' },
          provider: { type: 'string' },
          category: ref('Category'),
          recipientType: { type: 'string', enum: ['MSISDN', 'METER'] },
          pricing: ref('Pricing'),
          active: { type: 'boolean' },
        },
      },
      Me: {
        type: 'object',
        additionalProperties: false,
        required: ['id', 'username', 'displayName', 'createdAt'],
        properties: {
          id: { type: 'string', format: 'uuid' },
          username: { type: 'string' },
          displayName: { type: 'string' },
          createdAt: { type: 'string', format: 'date-time' },
        },
      },
      Wallet: {
        type: 'object',
        additionalProperties: false,
        required: ['balanceCents', 'currency'],
        properties: { balanceCents: { type: 'integer' }, currency: { type: 'string', enum: ['ZAR'] } },
      },
      TopupRequest: {
        type: 'object',
        required: ['amountCents'],
        properties: { amountCents: { type: 'integer', minimum: 1000, maximum: 500000 } },
      },
      TopupResponse: {
        type: 'object',
        additionalProperties: false,
        required: ['transactionId', 'amountCents', 'balanceCents', 'currency'],
        properties: {
          transactionId: { type: 'string', format: 'uuid' },
          amountCents: { type: 'integer' },
          balanceCents: { type: 'integer' },
          currency: { type: 'string', enum: ['ZAR'] },
        },
      },
      LedgerEntry: {
        type: 'object',
        additionalProperties: false,
        required: ['id', 'type', 'amountCents', 'balanceAfterCents', 'reference', 'createdAt'],
        properties: {
          id: { type: 'string', format: 'uuid' },
          type: { type: 'string', enum: ['TOPUP', 'PURCHASE', 'REFUND'] },
          amountCents: { type: 'integer', description: 'Signed: negative for PURCHASE' },
          balanceAfterCents: { type: 'integer' },
          reference: { type: 'string', description: 'Purchase id for PURCHASE/REFUND entries' },
          createdAt: { type: 'string', format: 'date-time' },
        },
      },
      PurchaseRequest: {
        type: 'object',
        required: ['productId', 'recipient'],
        properties: {
          productId: { type: 'string' },
          recipient: {
            type: 'object',
            description:
              'msisdn (0821234567 or +27821234567) for MSISDN products; meterNumber (11 digits) for METER products',
            properties: { msisdn: { type: 'string' }, meterNumber: { type: 'string', pattern: '^\\d{11}$' } },
          },
          amountCents: {
            type: 'integer',
            description: 'Required for VARIABLE pricing (within min/max, multiple of step); must be omitted for FIXED',
          },
        },
      },
      Fulfilment: {
        oneOf: [
          {
            type: 'object',
            additionalProperties: false,
            required: ['type'],
            properties: { type: { type: 'string', enum: ['DIRECT_TOPUP'] } },
          },
          {
            type: 'object',
            additionalProperties: false,
            required: ['type', 'pin', 'serial', 'expiresAt'],
            properties: {
              type: { type: 'string', enum: ['PIN'] },
              pin: { type: 'string', pattern: '^\\d{16}$' },
              serial: { type: 'string', pattern: '^VCH\\d{10}$' },
              expiresAt: { type: 'string', format: 'date-time' },
            },
          },
          {
            type: 'object',
            additionalProperties: false,
            required: ['type', 'token', 'units'],
            properties: {
              type: { type: 'string', enum: ['ELECTRICITY_TOKEN'] },
              token: { type: 'string', pattern: '^\\d{20}$' },
              units: { type: 'number', description: 'kWh' },
            },
          },
        ],
      },
      Purchase: {
        type: 'object',
        additionalProperties: false,
        required: [
          'id',
          'status',
          'product',
          'recipient',
          'amountCents',
          'currency',
          'failureReason',
          'fulfilment',
          'createdAt',
          'updatedAt',
          'completedAt',
        ],
        properties: {
          id: { type: 'string', format: 'uuid' },
          status: ref('PurchaseStatus'),
          product: {
            type: 'object',
            additionalProperties: false,
            required: ['id', 'sku', 'name', 'category', 'provider'],
            properties: {
              id: { type: 'string', format: 'uuid' },
              sku: { type: 'string' },
              name: { type: 'string' },
              category: ref('Category'),
              provider: { type: 'string' },
            },
          },
          recipient: {
            type: 'object',
            additionalProperties: false,
            properties: {
              msisdn: { type: 'string', pattern: '^\\+27[678]\\d{8}$', description: 'Normalised to E.164' },
              meterNumber: { type: 'string', pattern: '^\\d{11}$' },
            },
          },
          amountCents: { type: 'integer' },
          currency: { type: 'string', enum: ['ZAR'] },
          failureReason: { type: ['string', 'null'], enum: ['PROVIDER_REJECTED', null] },
          fulfilment: { oneOf: [ref('Fulfilment'), { type: 'null' }] },
          createdAt: { type: 'string', format: 'date-time' },
          updatedAt: { type: 'string', format: 'date-time' },
          completedAt: { type: ['string', 'null'], format: 'date-time' },
        },
      },
      CreateTestUserRequest: {
        type: 'object',
        properties: {
          balanceCents: { type: 'integer', minimum: 0, maximum: 10000000, default: 0 },
          locked: { type: 'boolean', default: false },
          displayName: { type: 'string' },
        },
      },
      TestUser: {
        type: 'object',
        additionalProperties: false,
        required: ['id', 'username', 'password', 'balanceCents', 'locked'],
        properties: {
          id: { type: 'string', format: 'uuid' },
          username: { type: 'string' },
          password: { type: 'string' },
          balanceCents: { type: 'integer' },
          locked: { type: 'boolean' },
        },
      },
    },
  },
};

module.exports = { spec };

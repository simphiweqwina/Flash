import { randomDigits } from './identifiers';

// The provider simulator decides the outcome from the last four digits: 0000 rejects, 9999 is slow.
export type ProviderOutcome = 'success' | 'rejected' | 'slow';

const SUFFIX: Record<Exclude<ProviderOutcome, 'success'>, string> = { rejected: '0000', slow: '9999' };

function withOutcome(prefix: string, length: number, outcome: ProviderOutcome): string {
  if (outcome !== 'success') return prefix + randomDigits(length - prefix.length - 4) + SUFFIX[outcome];
  let value: string;
  do {
    value = prefix + randomDigits(length - prefix.length);
  } while (value.endsWith('0000') || value.endsWith('9999'));
  return value;
}

export const Recipients = {
  msisdn: (outcome: ProviderOutcome = 'success'): string => withOutcome('082', 10, outcome),
  meterNumber: (outcome: ProviderOutcome = 'success'): string => withOutcome('', 11, outcome),
  toE164: (localMsisdn: string): string => `+27${localMsisdn.slice(1)}`,
} as const;

import { randomInt, randomUUID } from 'node:crypto';

export const newIdempotencyKey = (): string => `pw-${randomUUID()}`;

export const randomDigits = (length: number): string => Array.from({ length }, () => randomInt(10)).join('');

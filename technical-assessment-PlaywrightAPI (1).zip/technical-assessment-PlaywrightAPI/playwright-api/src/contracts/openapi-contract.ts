import type { APIRequestContext } from '@playwright/test';
import Ajv2020, { type ErrorObject, type ValidateFunction } from 'ajv/dist/2020';
import addFormats from 'ajv-formats';
import type { ApiResponse } from '../http/api-response';

interface ResponseObject {
  content?: Record<string, { schema?: unknown }>;
}

interface OperationObject {
  responses: Record<string, ResponseObject>;
}

export interface OpenApiDocument {
  openapi: string;
  paths: Record<string, Record<string, OperationObject>>;
}

interface Route {
  readonly method: string;
  readonly template: string;
  readonly matcher: RegExp;
  readonly operation: OperationObject;
}

const SPEC_ID = 'https://paypoint.test/openapi.json';
const JSON_MEDIA_TYPE = 'application/json';

const pointer = (...segments: string[]): string =>
  segments.map((s) => encodeURIComponent(s.replace(/~/g, '~0').replace(/\//g, '~1'))).join('/');

const formatErrors = (errors: ErrorObject[] | null | undefined): string[] =>
  (errors ?? []).map(
    (e) => `${e.instancePath || '(root)'} ${e.message ?? 'is invalid'} ${JSON.stringify(e.params)}`,
  );

export class ContractViolationError extends Error {
  override readonly name = 'ContractViolationError';
}

// Checks status and body of real responses against the OpenAPI document served by the API itself.
export class OpenApiContract {
  private static readonly cache = new Map<string, Promise<OpenApiContract>>();

  private readonly ajv: Ajv2020;
  private readonly routes: Route[];
  private readonly validators = new Map<string, ValidateFunction>();

  private constructor(document: OpenApiDocument) {
    this.ajv = new Ajv2020({ strict: false, allErrors: true, validateSchema: false });
    addFormats(this.ajv);
    this.ajv.addSchema(document, SPEC_ID);
    this.routes = Object.entries(document.paths).flatMap(([template, methods]) =>
      Object.entries(methods).map(([method, operation]) => ({
        method: method.toUpperCase(),
        template,
        matcher: new RegExp(
          `^${template.replace(/[.*+?^$()|[\]\\]/g, '\\$&').replace(/\{[^}]+\}/g, '[^/]+')}$`,
        ),
        operation,
      })),
    );
  }

  // Cached per worker and base URL.
  static load(request: APIRequestContext, baseURL: string): Promise<OpenApiContract> {
    let pending = OpenApiContract.cache.get(baseURL);
    if (!pending) {
      pending = (async () => {
        const response = await request.get(`${baseURL}/openapi.json`);
        if (!response.ok()) throw new Error(`Could not load OpenAPI document: HTTP ${response.status()}`);
        return new OpenApiContract((await response.json()) as OpenApiDocument);
      })();
      pending.catch(() => OpenApiContract.cache.delete(baseURL));
      OpenApiContract.cache.set(baseURL, pending);
    }
    return pending;
  }

  validate(response: ApiResponse<unknown>): string[] {
    const route = this.routes.find((r) => r.method === response.method && r.matcher.test(response.path));
    if (!route) return [`${response.method} ${response.path} is not a documented operation`];

    const label = `${response.method} ${route.template} -> ${response.status}`;
    const declared = route.operation.responses[String(response.status)] ?? route.operation.responses.default;
    if (!declared) {
      const documented = Object.keys(route.operation.responses).join(', ');
      return [`${label}: status is not documented (documented: ${documented})`];
    }

    const violations: string[] = [];
    const media = declared.content?.[JSON_MEDIA_TYPE];
    if (!media?.schema) return violations;

    const contentType = response.headers['content-type'] ?? '';
    if (!contentType.includes(JSON_MEDIA_TYPE)) {
      violations.push(`${label}: content-type "${contentType}" is not ${JSON_MEDIA_TYPE}`);
    }
    const ref = `${SPEC_ID}#/${pointer('paths', route.template, route.method.toLowerCase(), 'responses', String(response.status), 'content', JSON_MEDIA_TYPE, 'schema')}`;
    const validateBody = this.compile(ref);
    if (!validateBody(response.body)) {
      violations.push(...formatErrors(validateBody.errors).map((e) => `${label}: body ${e}`));
    }
    return violations;
  }

  assertResponse(response: ApiResponse<unknown>): void {
    const violations = this.validate(response);
    if (violations.length > 0) {
      throw new ContractViolationError(
        `Response violates the OpenAPI contract (request id ${response.requestId ?? 'n/a'}):\n  - ${violations.join('\n  - ')}\nBody: ${JSON.stringify(response.body)}`,
      );
    }
  }

  private compile(ref: string): ValidateFunction {
    let validator = this.validators.get(ref);
    if (!validator) {
      validator = this.ajv.compile({ $ref: ref });
      this.validators.set(ref, validator);
    }
    return validator;
  }
}

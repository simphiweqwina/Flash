import type { Product, PurchaseRequest, Recipient } from '../types/api';
import { Recipients, type ProviderOutcome } from '../data/recipients';

// Builds a valid request by default; tests override only what they care about.
export class PurchaseRequestBuilder {
  private recipient: Recipient;
  private amountCents: number | undefined;

  private constructor(private readonly product: Product) {
    this.recipient = PurchaseRequestBuilder.recipientFor(product, 'success');
    this.amountCents = product.pricing.type === 'VARIABLE' ? product.pricing.minCents : undefined;
  }

  static for(product: Product): PurchaseRequestBuilder {
    return new PurchaseRequestBuilder(product);
  }

  withProviderOutcome(outcome: ProviderOutcome): this {
    this.recipient = PurchaseRequestBuilder.recipientFor(this.product, outcome);
    return this;
  }

  withRecipient(recipient: Recipient): this {
    this.recipient = recipient;
    return this;
  }

  withAmount(amountCents: number | undefined): this {
    this.amountCents = amountCents;
    return this;
  }

  build(): PurchaseRequest {
    return {
      productId: this.product.id,
      recipient: { ...this.recipient },
      ...(this.amountCents === undefined ? {} : { amountCents: this.amountCents }),
    };
  }

  private static recipientFor(product: Product, outcome: ProviderOutcome): Recipient {
    return product.recipientType === 'METER'
      ? { meterNumber: Recipients.meterNumber(outcome) }
      : { msisdn: Recipients.msisdn(outcome) };
  }
}

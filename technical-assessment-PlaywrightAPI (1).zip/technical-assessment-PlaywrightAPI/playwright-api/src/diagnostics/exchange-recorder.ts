import type { TestInfo } from '@playwright/test';

const SECRET_KEYS = new Set([
  'password',
  'accesstoken',
  'refreshtoken',
  'authorization',
  'x-test-support-key',
]);

export interface Exchange {
  readonly at: string;
  readonly method: string;
  readonly path: string;
  readonly query?: Record<string, unknown> | undefined;
  readonly attempt: number;
  readonly requestHeaders: Record<string, string>;
  readonly requestBody: unknown;
  readonly status: number;
  readonly durationMs: number;
  readonly responseHeaders: Record<string, string>;
  readonly responseBody: unknown;
}

function redact(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(redact);
  if (value === null || typeof value !== 'object') return value;
  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>).map(([key, v]) =>
      SECRET_KEYS.has(key.toLowerCase()) && typeof v === 'string' ? [key, '[redacted]'] : [key, redact(v)],
    ),
  );
}

// Attached to the report as api-exchanges.json when a test fails or a request was retried.
export class ExchangeRecorder {
  private readonly exchanges: Exchange[] = [];

  record(exchange: Exchange): void {
    this.exchanges.push(redact(exchange) as Exchange);
  }

  async attachTo(testInfo: TestInfo): Promise<void> {
    const retries = this.exchanges.filter((e) => e.attempt > 1).length;
    if (retries > 0) {
      testInfo.annotations.push({ type: 'retried-requests', description: `${retries} request(s) retried` });
    }
    if (testInfo.status !== testInfo.expectedStatus || retries > 0) {
      await testInfo.attach('api-exchanges.json', {
        body: JSON.stringify(this.exchanges, null, 2),
        contentType: 'application/json',
      });
    }
  }
}

import { expect } from '@playwright/test';

export interface PollOptions {
  description: string;
  timeoutMs: number;
  intervalsMs?: number[];
}

// Polls until isDone or the deadline; returns the last value seen.
export async function pollUntil<T>(
  probe: () => Promise<T>,
  isDone: (value: T) => boolean,
  { description, timeoutMs, intervalsMs = [100, 250, 500, 1_000] }: PollOptions,
): Promise<T> {
  let last: T | undefined;
  await expect
    .poll(
      async () => {
        last = await probe();
        return isDone(last);
      },
      { message: description, timeout: timeoutMs, intervals: intervalsMs },
    )
    .toBe(true);
  return last as T;
}

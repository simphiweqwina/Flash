import { expectStatus } from '../assertions/http';
import { GlobalStateClient } from '../clients/test-support.client';
import { env } from '../config/env';
import { test as apiTest } from './api.fixture';

interface GlobalStateFixtures {
  globalState: GlobalStateClient;
}

export const test = apiTest.extend<GlobalStateFixtures>({
  globalState: async ({ http, isolatedServer }, use) => {
    if (!isolatedServer) {
      throw new Error('Global-state fixtures may only run in a project with isolatedServer: true');
    }
    const client = new GlobalStateClient(http, env.testSupportKey);
    expectStatus(await client.reset(), 204);
    await use(client);
    expectStatus(await client.reset(), 204);
  },

  // Depending on globalState makes sure users are created after the reset.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  createUser: async ({ globalState: _resetFirst, createUser }, use) => {
    await use(createUser);
  },
});

export { expect } from '@playwright/test';

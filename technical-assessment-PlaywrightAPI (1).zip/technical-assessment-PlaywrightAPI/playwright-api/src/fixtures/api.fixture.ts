import { test as base, expect } from '@playwright/test';
import { Customer, type Session } from '../actors/customer';
import { expectStatus } from '../assertions/http';
import { AuthClient } from '../clients/auth.client';
import { MetaClient } from '../clients/meta.client';
import { ProductClient } from '../clients/product.client';
import { TestSupportClient } from '../clients/test-support.client';
import { env } from '../config/env';
import { OpenApiContract } from '../contracts/openapi-contract';
import { DEFAULT_BALANCE_CENTS } from '../data/catalogue';
import { ExchangeRecorder } from '../diagnostics/exchange-recorder';
import { HttpClient } from '../http/http-client';
import type { CreateTestUserRequest, TestUser } from '../types/api';

export interface ApiTestOptions {
  // True only for projects with a dedicated server where global state may be changed.
  isolatedServer: boolean;
}

export interface ApiWorkerOptions {
  // Same as use.baseURL, which worker fixtures cannot read.
  apiBaseUrl: string;
}

interface WorkerFixtures {
  sharedAccount: { user: TestUser; session: Session };
}

export interface PublicApi {
  readonly auth: AuthClient;
  readonly products: ProductClient;
  readonly meta: MetaClient;
  readonly testSupport: TestSupportClient;
}

export interface ApiFixtures {
  recorder: ExchangeRecorder;
  contract: OpenApiContract;
  http: HttpClient;
  api: PublicApi;
  // New user with R500.00, not signed in.
  createUser: (request?: CreateTestUserRequest) => Promise<TestUser>;
  createCustomer: (request?: CreateTestUserRequest) => Promise<Customer>;
  // New signed-in user with R500.00, unique to the test.
  customer: Customer;
  // One signed-in user per worker for tests that must not move money; saves logins under the rate limit.
  readOnlyCustomer: Customer;
}

export const test = base.extend<ApiTestOptions & ApiFixtures, ApiWorkerOptions & WorkerFixtures>({
  isolatedServer: [false, { option: true }],
  apiBaseUrl: ['', { option: true, scope: 'worker' }],

  sharedAccount: [
    async ({ playwright, apiBaseUrl }, use) => {
      const request = await playwright.request.newContext({ baseURL: apiBaseUrl });
      try {
        const http = new HttpClient({ request, reportSteps: false });
        const user = expectStatus(
          await new TestSupportClient(http, env.testSupportKey).createUser({
            balanceCents: DEFAULT_BALANCE_CENTS,
          }),
          201,
        );
        const { session } = await Customer.signIn(http, user);
        await use({ user, session });
      } finally {
        await request.dispose();
      }
    },
    { scope: 'worker', timeout: 120_000 },
  ],

  // eslint-disable-next-line no-empty-pattern
  recorder: async ({}, use, testInfo) => {
    const recorder = new ExchangeRecorder();
    await use(recorder);
    await recorder.attachTo(testInfo);
  },

  contract: async ({ request, baseURL }, use) => {
    if (!baseURL) throw new Error('Every project must configure use.baseURL');
    await use(await OpenApiContract.load(request, baseURL));
  },

  http: async ({ request, contract, recorder }, use) => {
    await use(new HttpClient({ request, contract, recorder }));
  },

  api: async ({ http }, use) => {
    await use({
      auth: new AuthClient(http),
      products: new ProductClient(http),
      meta: new MetaClient(http),
      testSupport: new TestSupportClient(http, env.testSupportKey),
    });
  },

  createUser: async ({ api }, use) => {
    await use(async (request = {}) =>
      expectStatus(
        await api.testSupport.createUser({ balanceCents: DEFAULT_BALANCE_CENTS, ...request }),
        201,
      ),
    );
  },

  createCustomer: async ({ http, createUser }, use) => {
    await use(async (request) => Customer.signIn(http, await createUser(request)));
  },

  customer: async ({ createCustomer }, use) => {
    await use(await createCustomer());
  },

  readOnlyCustomer: async ({ http, sharedAccount, isolatedServer }, use) => {
    if (isolatedServer)
      throw new Error('readOnlyCustomer does not survive resets; use createCustomer instead');
    const customer = Customer.fromSession(http, sharedAccount.user, sharedAccount.session);
    if (customer.session.expiresWithin(60_000)) {
      customer.session.update(expectStatus(await customer.auth.refresh(customer.session.refreshToken), 200));
    }

    await use(customer);

    expect(await customer.balanceCents(), 'readOnlyCustomer must never move money').toBe(
      sharedAccount.user.balanceCents,
    );
  },
});

export { expect } from '@playwright/test';

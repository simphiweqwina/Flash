// Compile-time types only; runtime responses are validated against /openapi.json.

export type Category = 'AIRTIME' | 'DATA' | 'VOUCHER' | 'ELECTRICITY';
export type RecipientType = 'MSISDN' | 'METER';
export type PurchaseStatus = 'PENDING' | 'SUCCESSFUL' | 'FAILED';
export type LedgerEntryType = 'TOPUP' | 'PURCHASE' | 'REFUND';

export interface ErrorDetail {
  field: string;
  issue: string;
}

export interface ApiErrorBody {
  code: string;
  message: string;
  requestId: string;
  details?: ErrorDetail[];
}

export interface ErrorEnvelope {
  error: ApiErrorBody;
}

export interface Page<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface PageQuery {
  page?: number;
  pageSize?: number;
}

export interface Health {
  status: 'ok';
  version: string;
  uptimeSeconds: number;
}

export interface Features {
  electricity?: boolean;
}

export interface Credentials {
  username: string;
  password: string;
}

export interface TokenResponse {
  accessToken: string;
  tokenType: 'Bearer';
  expiresIn: number;
  refreshToken: string;
}

export type Pricing =
  | { type: 'FIXED'; priceCents: number }
  | { type: 'VARIABLE'; minCents: number; maxCents: number; stepCents: number };

export interface Product {
  id: string;
  sku: string;
  name: string;
  provider: string;
  category: Category;
  recipientType: RecipientType;
  pricing: Pricing;
  active: boolean;
}

export interface ProductQuery extends PageQuery {
  category?: Category;
  provider?: string;
  sort?: 'name' | '-name' | 'price' | '-price';
}

export interface Me {
  id: string;
  username: string;
  displayName: string;
  createdAt: string;
}

export interface Wallet {
  balanceCents: number;
  currency: 'ZAR';
}

export interface TopupResponse {
  transactionId: string;
  amountCents: number;
  balanceCents: number;
  currency: 'ZAR';
}

export interface LedgerEntry {
  id: string;
  type: LedgerEntryType;
  amountCents: number;
  balanceAfterCents: number;
  reference: string;
  createdAt: string;
}

export interface LedgerQuery extends PageQuery {
  type?: LedgerEntryType;
}

export interface Recipient {
  msisdn?: string;
  meterNumber?: string;
}

export interface PurchaseRequest {
  productId: string;
  recipient: Recipient;
  amountCents?: number;
}

export type Fulfilment =
  | { type: 'DIRECT_TOPUP' }
  | { type: 'PIN'; pin: string; serial: string; expiresAt: string }
  | { type: 'ELECTRICITY_TOKEN'; token: string; units: number };

export interface Purchase {
  id: string;
  status: PurchaseStatus;
  product: Pick<Product, 'id' | 'sku' | 'name' | 'category' | 'provider'>;
  recipient: Recipient;
  amountCents: number;
  currency: 'ZAR';
  failureReason: 'PROVIDER_REJECTED' | null;
  fulfilment: Fulfilment | null;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

export interface PurchaseQuery extends PageQuery {
  status?: PurchaseStatus;
  category?: Category;
}

export interface CreateTestUserRequest {
  balanceCents?: number;
  locked?: boolean;
  displayName?: string;
}

export interface TestUser {
  id: string;
  username: string;
  password: string;
  balanceCents: number;
  locked: boolean;
}

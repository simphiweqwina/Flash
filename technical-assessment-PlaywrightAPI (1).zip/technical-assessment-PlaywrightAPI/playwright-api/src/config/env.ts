const apiPort = Number(process.env.API_PORT ?? 3100);
const isolatedApiPort = Number(process.env.ISOLATED_API_PORT ?? 3101);
const externalApi = process.env.API_BASE_URL;

export const env = {
  isCI: Boolean(process.env.CI),
  // Servers are only started locally; an external API_BASE_URL is assumed to be running already.
  manageServers: externalApi === undefined,
  apiPort,
  isolatedApiPort,
  apiBaseUrl: externalApi ?? `http://localhost:${apiPort}`,
  // Undefined means there is nowhere safe to change global state, so the global-state project is skipped.
  isolatedApiBaseUrl:
    process.env.ISOLATED_API_BASE_URL ??
    (externalApi === undefined ? `http://localhost:${isolatedApiPort}` : undefined),
  testSupportKey: process.env.TEST_SUPPORT_KEY ?? 'qa-assessment-key',
  reuseServer: process.env.REUSE_SERVER === 'true',
} as const;

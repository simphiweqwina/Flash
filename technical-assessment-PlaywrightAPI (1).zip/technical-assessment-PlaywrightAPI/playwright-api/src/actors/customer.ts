import { expectStatus } from '../assertions/http';
import { AccountClient } from '../clients/account.client';
import { AuthClient } from '../clients/auth.client';
import { PurchaseClient } from '../clients/purchase.client';
import type { HttpClient } from '../http/http-client';
import type { LedgerEntry, Purchase, PurchaseRequest, TestUser, TokenResponse } from '../types/api';

// Mutable so clients always send the latest access token after a refresh.
export class Session {
  accessToken!: string;
  refreshToken!: string;
  private expiresAt = 0;

  constructor(tokens: TokenResponse) {
    this.update(tokens);
  }

  update(tokens: TokenResponse): void {
    this.accessToken = tokens.accessToken;
    this.refreshToken = tokens.refreshToken;
    this.expiresAt = Date.now() + tokens.expiresIn * 1_000;
  }

  expiresWithin(ms: number): boolean {
    return this.expiresAt - Date.now() < ms;
  }
}

export class Customer {
  readonly auth: AuthClient;
  readonly account: AccountClient;
  readonly purchases: PurchaseClient;

  private constructor(
    readonly user: TestUser,
    readonly session: Session,
    http: HttpClient,
  ) {
    const authenticated = http.withAuth(() => this.session.accessToken);
    this.auth = new AuthClient(authenticated);
    this.account = new AccountClient(authenticated);
    this.purchases = new PurchaseClient(authenticated);
  }

  static async signIn(http: HttpClient, user: TestUser): Promise<Customer> {
    const tokens = expectStatus(
      await new AuthClient(http).login({ username: user.username, password: user.password }),
      200,
    );
    return new Customer(user, new Session(tokens), http);
  }

  static fromSession(http: HttpClient, user: TestUser, session: Session): Customer {
    return new Customer(user, session, http);
  }

  async balanceCents(): Promise<number> {
    return expectStatus(await this.account.wallet(), 200).balanceCents;
  }

  async ledger(): Promise<LedgerEntry[]> {
    const entries: LedgerEntry[] = [];
    for (let page = 1; ; page++) {
      const result = expectStatus(await this.account.transactions({ page, pageSize: 50 }), 200);
      entries.push(...result.items);
      if (page >= result.totalPages) return entries;
    }
  }

  async purchaseAndSettle(request: PurchaseRequest): Promise<{ accepted: Purchase; settled: Purchase }> {
    const accepted = expectStatus(await this.purchases.create(request), 202);
    const settled = await this.purchases.waitForSettlement(accepted.id);
    return { accepted, settled };
  }
}

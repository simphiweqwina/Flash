import { expectStatus } from '../assertions/http';
import type { ApiResponse } from '../http/api-response';
import type { HttpClient, QueryParams } from '../http/http-client';
import type { Page, Product, ProductQuery } from '../types/api';

export class ProductClient {
  constructor(private readonly http: HttpClient) {}

  list(query: ProductQuery | QueryParams = {}): Promise<ApiResponse<Page<Product>>> {
    return this.http.get<Page<Product>>('/products', { query: { ...query } });
  }

  get(id: string): Promise<ApiResponse<Product>> {
    return this.http.get<Product>(`/products/${encodeURIComponent(id)}`);
  }

  // Ids change on every server start; the SKU is stable.
  async bySku(sku: string): Promise<Product> {
    const page = expectStatus(await this.list({ pageSize: 50 }), 200);
    const product = page.items.find((p) => p.sku === sku);
    if (!product) throw new Error(`No visible product with SKU "${sku}" in the catalogue`);
    return product;
  }
}

import type { ApiResponse } from '../http/api-response';
import type { HttpClient } from '../http/http-client';
import { TRANSIENT_AND_RATE_LIMIT, type RetryPolicy } from '../http/retry-policy';
import type { Credentials, TokenResponse } from '../types/api';

export class AuthClient {
  constructor(private readonly http: HttpClient) {}

  login(
    credentials: Credentials | Record<string, unknown>,
    retry: RetryPolicy = TRANSIENT_AND_RATE_LIMIT,
  ): Promise<ApiResponse<TokenResponse>> {
    return this.http.post<TokenResponse>('/auth/login', { json: credentials, retry });
  }

  refresh(refreshToken: string): Promise<ApiResponse<TokenResponse>> {
    return this.http.post<TokenResponse>('/auth/refresh', { json: { refreshToken } });
  }

  logout(): Promise<ApiResponse<undefined>> {
    return this.http.post<undefined>('/auth/logout');
  }
}

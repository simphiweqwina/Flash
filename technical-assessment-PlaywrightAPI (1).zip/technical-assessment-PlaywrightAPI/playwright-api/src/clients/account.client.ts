import type { ApiResponse } from '../http/api-response';
import type { HttpClient } from '../http/http-client';
import type { LedgerEntry, LedgerQuery, Me, Page, TopupResponse, Wallet } from '../types/api';

export class AccountClient {
  constructor(private readonly http: HttpClient) {}

  me(): Promise<ApiResponse<Me>> {
    return this.http.get<Me>('/me');
  }

  wallet(): Promise<ApiResponse<Wallet>> {
    return this.http.get<Wallet>('/wallet');
  }

  topUp(amountCents: unknown): Promise<ApiResponse<TopupResponse>> {
    return this.http.post<TopupResponse>('/wallet/topups', { json: { amountCents } });
  }

  transactions(query: LedgerQuery = {}): Promise<ApiResponse<Page<LedgerEntry>>> {
    return this.http.get<Page<LedgerEntry>>('/wallet/transactions', { query: { ...query } });
  }
}

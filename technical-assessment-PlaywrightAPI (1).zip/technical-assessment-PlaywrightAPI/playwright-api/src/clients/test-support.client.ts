import type { ApiResponse } from '../http/api-response';
import type { HttpClient } from '../http/http-client';
import type { CreateTestUserRequest, Features, TestUser } from '../types/api';

// Global-state operations live on GlobalStateClient, which only the isolated project can obtain.
export class TestSupportClient {
  constructor(
    protected readonly http: HttpClient,
    protected readonly key: string,
  ) {}

  createUser(request: CreateTestUserRequest = {}): Promise<ApiResponse<TestUser>> {
    return this.http.post<TestUser>('/__test__/users', { json: request, headers: this.headers() });
  }

  expireToken(accessToken: string): Promise<ApiResponse<undefined>> {
    return this.http.post<undefined>('/__test__/tokens/expire', {
      json: { accessToken },
      headers: this.headers(),
    });
  }

  protected headers(): Record<string, string> {
    return { 'X-Test-Support-Key': this.key };
  }
}

export class GlobalStateClient extends TestSupportClient {
  setFeatures(features: Features): Promise<ApiResponse<Features>> {
    return this.http.put<Features>('/__test__/features', { json: features, headers: this.headers() });
  }

  reset(): Promise<ApiResponse<undefined>> {
    return this.http.post<undefined>('/__test__/reset', { headers: this.headers() });
  }
}

import { expectStatus } from '../assertions/http';
import type { ApiResponse } from '../http/api-response';
import type { HttpClient } from '../http/http-client';
import type { Page, Purchase, PurchaseQuery, PurchaseRequest } from '../types/api';
import { pollUntil } from '../utils/polling';
import { newIdempotencyKey } from '../data/identifiers';

// Covers the 0.5-4s normal fulfilment and the ~8s slow provider.
const FULFILMENT_DEADLINE_MS = 15_000;

export class PurchaseClient {
  constructor(private readonly http: HttpClient) {}

  create(
    request: PurchaseRequest | Record<string, unknown>,
    idempotencyKey: string | null = newIdempotencyKey(),
  ): Promise<ApiResponse<Purchase>> {
    const headers: Record<string, string> =
      idempotencyKey === null ? {} : { 'Idempotency-Key': idempotencyKey };
    return this.http.post<Purchase>('/purchases', { json: request, headers });
  }

  get(id: string): Promise<ApiResponse<Purchase>> {
    return this.http.get<Purchase>(`/purchases/${encodeURIComponent(id)}`);
  }

  list(query: PurchaseQuery = {}): Promise<ApiResponse<Page<Purchase>>> {
    return this.http.get<Page<Purchase>>('/purchases', { query: { ...query } });
  }

  waitForSettlement(id: string, timeoutMs = FULFILMENT_DEADLINE_MS): Promise<Purchase> {
    return pollUntil(
      async () => expectStatus(await this.get(id), 200),
      (purchase) => purchase.status !== 'PENDING',
      { description: `purchase ${id} to leave PENDING within ${timeoutMs}ms`, timeoutMs },
    );
  }
}

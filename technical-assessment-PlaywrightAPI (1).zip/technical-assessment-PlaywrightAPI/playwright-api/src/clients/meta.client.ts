import type { ApiResponse } from '../http/api-response';
import type { HttpClient } from '../http/http-client';
import type { Features, Health } from '../types/api';

export class MetaClient {
  constructor(private readonly http: HttpClient) {}

  health(): Promise<ApiResponse<Health>> {
    return this.http.get<Health>('/health');
  }

  features(): Promise<ApiResponse<Features>> {
    return this.http.get<Features>('/config/features');
  }
}

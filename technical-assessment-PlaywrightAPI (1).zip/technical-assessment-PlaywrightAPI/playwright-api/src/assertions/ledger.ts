import { expect } from '@playwright/test';
import type { LedgerEntry } from '../types/api';

// Ledger entries (newest first) must form an unbroken running balance ending at the wallet balance.
export function expectLedgerToReconcile(entries: readonly LedgerEntry[], balanceCents: number): void {
  const total = entries.reduce((sum, e) => sum + e.amountCents, 0);
  expect(total, 'sum of ledger entries must equal the wallet balance').toBe(balanceCents);
  expect(entries[0]?.balanceAfterCents ?? 0, 'latest balanceAfterCents must equal the wallet balance').toBe(
    balanceCents,
  );

  entries.forEach((entry, i) => {
    const previousBalance = entries[i + 1]?.balanceAfterCents ?? 0;
    expect(
      entry.balanceAfterCents,
      `running balance broken at ledger entry ${entry.id} (${entry.type})`,
    ).toBe(previousBalance + entry.amountCents);
  });
}

export const entriesFor = (entries: readonly LedgerEntry[], reference: string): LedgerEntry[] =>
  entries.filter((e) => e.reference === reference);

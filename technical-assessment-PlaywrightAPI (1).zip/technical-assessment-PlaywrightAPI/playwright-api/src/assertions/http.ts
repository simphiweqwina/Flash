import { expect } from '@playwright/test';
import type { ApiResponse } from '../http/api-response';
import { isErrorEnvelope } from '../http/api-response';
import type { ApiErrorBody } from '../types/api';

const describe = (res: ApiResponse<unknown>): string =>
  `${res.method} ${res.path} [request id ${res.requestId ?? 'n/a'}] responded ${res.status}: ${JSON.stringify(res.body)}`;

export function expectStatus<T>(res: ApiResponse<T>, status: number): T {
  expect(res.status, describe(res)).toBe(status);
  return res.body as T;
}

export function expectApiError(res: ApiResponse<unknown>, status: number, code: string): ApiErrorBody {
  expect(res.status, describe(res)).toBe(status);
  expect(isErrorEnvelope(res.body), `expected an error envelope: ${describe(res)}`).toBe(true);
  const error = (res.body as { error: ApiErrorBody }).error;
  expect(error.code, describe(res)).toBe(code);
  expect(error.requestId, 'error.requestId must match the X-Request-Id header').toBe(res.requestId);
  return error;
}

export function expectValidationError(res: ApiResponse<unknown>, field: string): ApiErrorBody {
  const error = expectApiError(res, 400, 'VALIDATION_ERROR');
  expect(
    error.details?.map((d) => d.field),
    describe(res),
  ).toContain(field);
  return error;
}

import type { ErrorEnvelope } from '../types/api';

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export interface ApiResponse<TSuccess> {
  readonly method: HttpMethod;
  readonly path: string;
  readonly status: number;
  readonly headers: Readonly<Record<string, string>>;
  readonly body: TSuccess | ErrorEnvelope | undefined;
  readonly requestId: string | undefined;
  readonly attempts: number;
}

export const isErrorEnvelope = (body: unknown): body is ErrorEnvelope =>
  typeof body === 'object' && body !== null && 'error' in body;

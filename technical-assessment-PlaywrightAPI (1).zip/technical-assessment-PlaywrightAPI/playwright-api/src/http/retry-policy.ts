// Only 503 (documented as side-effect free) and 429 (admission control) are ever retried.
export interface RetryPolicy {
  readonly maxAttempts: number;
  readonly retryOnStatus: readonly number[];
  readonly maxDelayMs: number;
}

export const TRANSIENT_ONLY: RetryPolicy = { maxAttempts: 4, retryOnStatus: [503], maxDelayMs: 5_000 };

// For logins: the 20/min per-IP limit is shared by all workers, so a 429 is environmental.
export const TRANSIENT_AND_RATE_LIMIT: RetryPolicy = {
  maxAttempts: 10,
  retryOnStatus: [503, 429],
  maxDelayMs: 65_000,
};

export function retryDelayMs(retryAfterHeader: string | undefined, policy: RetryPolicy): number {
  const seconds = Number(retryAfterHeader);
  const requested = Number.isFinite(seconds) && seconds > 0 ? seconds * 1_000 : 1_000;
  return Math.min(requested, policy.maxDelayMs);
}

export const backOff = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

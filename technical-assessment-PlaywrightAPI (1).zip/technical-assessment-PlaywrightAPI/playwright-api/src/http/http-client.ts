import { randomBytes } from 'node:crypto';
import { test, type APIRequestContext, type APIResponse } from '@playwright/test';
import type { OpenApiContract } from '../contracts/openapi-contract';
import type { ExchangeRecorder } from '../diagnostics/exchange-recorder';
import type { ApiResponse, HttpMethod } from './api-response';
import { backOff, retryDelayMs, TRANSIENT_ONLY, type RetryPolicy } from './retry-policy';

export type QueryParams = Record<string, string | number | boolean | undefined>;

export interface RequestOptions {
  query?: QueryParams | undefined;
  headers?: Record<string, string>;
  json?: unknown;
  // Sent as-is, for malformed-body and media-type tests.
  raw?: { body: string; contentType: string };
  retry?: RetryPolicy;
}

export interface TransportContext {
  readonly request: APIRequestContext;
  readonly contract?: OpenApiContract | undefined;
  readonly recorder?: ExchangeRecorder | undefined;
  // test.step is unavailable in worker-scoped fixtures.
  readonly reportSteps?: boolean;
}

const compactQuery = (
  query: QueryParams | undefined,
): Record<string, string | number | boolean> | undefined =>
  query
    ? (Object.fromEntries(Object.entries(query).filter(([, v]) => v !== undefined)) as Record<
        string,
        string | number | boolean
      >)
    : undefined;

async function parseBody(response: APIResponse): Promise<unknown> {
  const text = await response.text();
  if (!text) return undefined;
  try {
    return JSON.parse(text) as unknown;
  } catch {
    return text;
  }
}

// The only place that sends HTTP: auth header, request ids, transient retries, contract checks, diagnostics.
export class HttpClient {
  private readonly runId = randomBytes(3).toString('hex');
  private sequence = 0;

  constructor(
    private readonly ctx: TransportContext,
    private readonly accessToken?: () => string | undefined,
  ) {}

  withAuth(accessToken: () => string | undefined): HttpClient {
    return new HttpClient(this.ctx, accessToken);
  }

  get<T>(path: string, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.send<T>('GET', path, options);
  }

  post<T>(path: string, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.send<T>('POST', path, options);
  }

  put<T>(path: string, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.send<T>('PUT', path, options);
  }

  send<T>(method: HttpMethod, path: string, options: RequestOptions = {}): Promise<ApiResponse<T>> {
    if (this.ctx.reportSteps === false) return this.execute<T>(method, path, options);
    return test.step(`${method} ${path}`, () => this.execute<T>(method, path, options), { box: true });
  }

  private async execute<T>(
    method: HttpMethod,
    path: string,
    options: RequestOptions,
  ): Promise<ApiResponse<T>> {
    const policy = options.retry ?? TRANSIENT_ONLY;
    const params = compactQuery(options.query);

    for (let attempt = 1; ; attempt++) {
      const headers = this.buildHeaders(options);
      const started = Date.now();
      const raw = await this.ctx.request.fetch(path, {
        method,
        headers,
        ...(params ? { params } : {}),
        ...(options.raw
          ? { data: options.raw.body }
          : options.json !== undefined
            ? { data: options.json }
            : {}),
        failOnStatusCode: false,
      });

      const responseHeaders = raw.headers();
      const response: ApiResponse<T> = {
        method,
        path,
        status: raw.status(),
        headers: responseHeaders,
        body: (await parseBody(raw)) as T,
        requestId: responseHeaders['x-request-id'],
        attempts: attempt,
      };
      this.ctx.recorder?.record({
        at: new Date(started).toISOString(),
        method,
        path,
        query: params,
        attempt,
        requestHeaders: headers,
        requestBody: options.raw?.body ?? options.json,
        status: response.status,
        durationMs: Date.now() - started,
        responseHeaders,
        responseBody: response.body,
      });

      this.ctx.contract?.assertResponse(response);

      if (attempt < policy.maxAttempts && policy.retryOnStatus.includes(response.status)) {
        await backOff(retryDelayMs(responseHeaders['retry-after'], policy));
        continue;
      }
      return response;
    }
  }

  private buildHeaders(options: RequestOptions): Record<string, string> {
    const headers: Record<string, string> = {
      'X-Request-Id': `pw-${this.runId}-${++this.sequence}`,
    };
    const token = this.accessToken?.();
    if (token) headers.Authorization = `Bearer ${token}`;
    if (options.raw) headers['Content-Type'] = options.raw.contentType;
    return { ...headers, ...options.headers };
  }
}

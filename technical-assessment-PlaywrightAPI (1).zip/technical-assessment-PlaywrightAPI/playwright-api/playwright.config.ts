import path from 'node:path';
import { defineConfig } from '@playwright/test';
import { env } from './src/config/env';
import type { ApiTestOptions, ApiWorkerOptions } from './src/fixtures/api.fixture';

// Started with the default server configuration (chaos included), which the suite must tolerate.
const server = (port: number) => ({
  command: 'node server/index.js',
  cwd: path.resolve(__dirname, '..'),
  url: `http://localhost:${port}/health`,
  env: { PORT: String(port), LOG_REQUESTS: 'false' },
  timeout: 30_000,
});

export default defineConfig<ApiTestOptions, ApiWorkerOptions>({
  fullyParallel: true,
  forbidOnly: env.isCI,
  // Transient failures are retried per request in HttpClient; retrying whole tests would hide flakiness.
  retries: 0,
  workers: env.isCI ? 4 : undefined,
  // A login may need to wait out the shared per-IP rate-limit window (up to 60s).
  timeout: 120_000,
  expect: { timeout: 10_000 },
  reporter: [
    [env.isCI ? 'github' : 'list'],
    ['html', { outputFolder: 'reports/html', open: 'never' }],
    ['junit', { outputFile: 'reports/junit/results.xml' }],
  ],
  outputDir: 'test-results',
  use: {
    extraHTTPHeaders: { Accept: 'application/json' },
  },
  webServer: env.manageServers
    ? [
        { ...server(env.apiPort), reuseExistingServer: env.reuseServer },
        { ...server(env.isolatedApiPort), reuseExistingServer: false },
      ]
    : undefined,
  projects: [
    {
      name: 'api',
      testDir: './tests/api',
      use: { baseURL: env.apiBaseUrl, apiBaseUrl: env.apiBaseUrl },
    },
    // Tests that change global server state run one at a time against their own server.
    ...(env.isolatedApiBaseUrl
      ? [
          {
            name: 'global-state',
            testDir: './tests/global-state',
            workers: 1,
            fullyParallel: false,
            use: {
              baseURL: env.isolatedApiBaseUrl,
              apiBaseUrl: env.isolatedApiBaseUrl,
              isolatedServer: true,
            },
          },
        ]
      : []),
  ],
});

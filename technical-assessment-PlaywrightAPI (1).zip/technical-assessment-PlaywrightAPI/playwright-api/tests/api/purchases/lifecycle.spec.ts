import { expectApiError, expectStatus } from '@src/assertions/http';
import { entriesFor, expectLedgerToReconcile } from '@src/assertions/ledger';
import { PurchaseRequestBuilder } from '@src/builders/purchase-request.builder';
import { DEFAULT_BALANCE_CENTS, Sku } from '@src/data/catalogue';
import { Recipients } from '@src/data/recipients';
import { expect, test } from '@src/fixtures/api.fixture';

test.describe('Purchase lifecycle', { tag: '@regression' }, () => {
  test(
    'successful airtime purchase debits once and settles SUCCESSFUL',
    { tag: '@smoke' },
    async ({ api, customer }) => {
      // Arrange
      const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
      const msisdn = Recipients.msisdn('success');
      const request = PurchaseRequestBuilder.for(product)
        .withRecipient({ msisdn })
        .withAmount(10_000)
        .build();

      // Act
      const { accepted, settled } = await customer.purchaseAndSettle(request);

      // Assert
      await test.step('accepted as PENDING with the recipient normalised to E.164', () => {
        expect(accepted).toMatchObject({
          status: 'PENDING',
          amountCents: 10_000,
          recipient: { msisdn: Recipients.toE164(msisdn) },
          product: { id: product.id, sku: product.sku },
          fulfilment: null,
          completedAt: null,
        });
      });

      await test.step('settled SUCCESSFUL with a direct top-up', () => {
        expect(settled).toMatchObject({ id: accepted.id, status: 'SUCCESSFUL', failureReason: null });
        expect(settled.fulfilment).toEqual({ type: 'DIRECT_TOPUP' });
        expect(settled.completedAt).not.toBeNull();
      });

      await test.step('wallet debited exactly once and ledger reconciles', async () => {
        const balance = await customer.balanceCents();
        expect(balance).toBe(DEFAULT_BALANCE_CENTS - 10_000);

        const ledger = await customer.ledger();
        expect(entriesFor(ledger, accepted.id)).toEqual([
          expect.objectContaining({ type: 'PURCHASE', amountCents: -10_000 }),
        ]);
        expectLedgerToReconcile(ledger, balance);
      });
    },
  );

  test('provider rejection settles FAILED and refunds the wallet in full', async ({ api, customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_MTN);
    const request = PurchaseRequestBuilder.for(product)
      .withProviderOutcome('rejected')
      .withAmount(10_000)
      .build();

    // Act
    const { accepted, settled } = await customer.purchaseAndSettle(request);

    // Assert
    expect(settled).toMatchObject({ status: 'FAILED', failureReason: 'PROVIDER_REJECTED', fulfilment: null });
    const balance = await customer.balanceCents();
    expect(balance, 'refund must restore the original balance').toBe(DEFAULT_BALANCE_CENTS);
    const ledger = await customer.ledger();
    expect(entriesFor(ledger, accepted.id).map((e) => [e.type, e.amountCents])).toEqual([
      ['REFUND', 10_000],
      ['PURCHASE', -10_000],
    ]);
    expectLedgerToReconcile(ledger, balance);
  });

  test('voucher purchase is fulfilled with a PIN and charged the fixed price', async ({ api, customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.VOUCHER_GIFT_100);
    if (product.pricing.type !== 'FIXED') throw new Error(`${product.sku} is expected to be fixed-price`);
    const request = PurchaseRequestBuilder.for(product).build();

    // Act
    const { settled } = await customer.purchaseAndSettle(request);

    // Assert
    expect(settled.status).toBe('SUCCESSFUL');
    expect(settled.amountCents).toBe(product.pricing.priceCents);
    expect(settled.fulfilment).toMatchObject({ type: 'PIN' });
    expect(await customer.balanceCents()).toBe(DEFAULT_BALANCE_CENTS - product.pricing.priceCents);
  });

  test('electricity purchase is fulfilled with a meter token', async ({ api, customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.ELECTRICITY_ESKOM);
    const request = PurchaseRequestBuilder.for(product).withAmount(28_500).build();

    // Act
    const { settled } = await customer.purchaseAndSettle(request);

    // Assert
    expect(settled.status).toBe('SUCCESSFUL');
    expect(settled.fulfilment).toMatchObject({ type: 'ELECTRICITY_TOKEN', units: 100 });
  });

  test(
    'a slow provider keeps the purchase PENDING until it settles',
    { tag: '@slow' },
    async ({ api, customer }) => {
      // Arrange
      const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
      const request = PurchaseRequestBuilder.for(product).withProviderOutcome('slow').build();

      // Act
      const accepted = expectStatus(await customer.purchases.create(request), 202);

      // Assert
      expect(expectStatus(await customer.purchases.get(accepted.id), 200).status).toBe('PENDING');
      const settled = await customer.purchases.waitForSettlement(accepted.id);
      expect(settled.status).toBe('SUCCESSFUL');
    },
  );

  test("a customer cannot see another customer's purchase", async ({ api, customer, createCustomer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const accepted = expectStatus(
      await customer.purchases.create(PurchaseRequestBuilder.for(product).build()),
      202,
    );
    const otherCustomer = await createCustomer();

    // Act
    const response = await otherCustomer.purchases.get(accepted.id);

    // Assert
    expectApiError(response, 404, 'PURCHASE_NOT_FOUND');
    expect(expectStatus(await otherCustomer.purchases.list(), 200).total).toBe(0);
  });
});

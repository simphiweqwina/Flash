import { expectApiError, expectStatus, expectValidationError } from '@src/assertions/http';
import { entriesFor } from '@src/assertions/ledger';
import { PurchaseRequestBuilder } from '@src/builders/purchase-request.builder';
import { DEFAULT_BALANCE_CENTS, Sku } from '@src/data/catalogue';
import { newIdempotencyKey } from '@src/data/identifiers';
import { expect, test } from '@src/fixtures/api.fixture';

test.describe('Purchase idempotency', { tag: '@regression' }, () => {
  test('replaying the same key and body returns the original purchase without charging again', async ({
    api,
    customer,
  }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const request = PurchaseRequestBuilder.for(product).withAmount(5_000).build();
    const key = newIdempotencyKey();
    const original = expectStatus(await customer.purchases.create(request, key), 202);

    // Act
    const response = await customer.purchases.create(request, key);

    // Assert
    const replay = expectStatus(response, 200);
    expect(response.headers['idempotent-replayed']).toBe('true');
    expect(replay.id).toBe(original.id);
    expect(await customer.balanceCents()).toBe(DEFAULT_BALANCE_CENTS - 5_000);
    expect(expectStatus(await customer.purchases.list(), 200).total).toBe(1);
  });

  test('reusing a key with a different body is a conflict and moves no money', async ({ api, customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const key = newIdempotencyKey();
    const first = expectStatus(
      await customer.purchases.create(PurchaseRequestBuilder.for(product).withAmount(5_000).build(), key),
      202,
    );
    const conflicting = PurchaseRequestBuilder.for(product).withAmount(6_000).build();

    // Act
    const response = await customer.purchases.create(conflicting, key);

    // Assert
    expectApiError(response, 409, 'IDEMPOTENCY_KEY_REUSED');
    expect(await customer.balanceCents()).toBe(DEFAULT_BALANCE_CENTS - 5_000);
    expect(entriesFor(await customer.ledger(), first.id)).toHaveLength(1);
  });

  test('keys are scoped per customer', async ({ api, customer, createCustomer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const request = PurchaseRequestBuilder.for(product).build();
    const key = newIdempotencyKey();
    const otherCustomer = await createCustomer();
    const mine = expectStatus(await customer.purchases.create(request, key), 202);

    // Act
    const response = await otherCustomer.purchases.create(request, key);

    // Assert
    const theirs = expectStatus(response, 202);
    expect(theirs.id).not.toBe(mine.id);
  });

  test(
    'concurrent submissions with one key create exactly one purchase',
    { tag: '@concurrency' },
    async ({ api, customer }) => {
      // Arrange
      const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
      const request = PurchaseRequestBuilder.for(product).withAmount(2_000).build();
      const key = newIdempotencyKey();

      // Act
      const responses = await Promise.all(
        Array.from({ length: 5 }, () => customer.purchases.create(request, key)),
      );

      // Assert
      expect(responses.map((r) => r.status).sort()).toEqual([200, 200, 200, 200, 202]);
      expect(new Set(responses.map((r) => (r.body as { id: string }).id)).size).toBe(1);
      expect(await customer.balanceCents()).toBe(DEFAULT_BALANCE_CENTS - 2_000);
    },
  );

  test('the Idempotency-Key header is required', async ({ api, readOnlyCustomer: customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const request = PurchaseRequestBuilder.for(product).build();

    // Act
    const response = await customer.purchases.create(request, null);

    // Assert
    expectApiError(response, 400, 'IDEMPOTENCY_KEY_REQUIRED');
  });

  for (const key of ['short', 'has spaces in it', 'x'.repeat(65), 'bad*chars!']) {
    test(`a malformed Idempotency-Key is rejected: "${key.slice(0, 20)}"`, async ({
      api,
      readOnlyCustomer: customer,
    }) => {
      // Arrange
      const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
      const request = PurchaseRequestBuilder.for(product).build();

      // Act
      const response = await customer.purchases.create(request, key);

      // Assert
      expectValidationError(response, 'Idempotency-Key');
    });
  }
});

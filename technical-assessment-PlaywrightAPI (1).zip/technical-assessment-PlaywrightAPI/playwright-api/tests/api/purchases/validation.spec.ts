import { expectApiError, expectStatus, expectValidationError } from '@src/assertions/http';
import { PurchaseRequestBuilder } from '@src/builders/purchase-request.builder';
import { Sku } from '@src/data/catalogue';
import { Recipients } from '@src/data/recipients';
import { expect, test } from '@src/fixtures/api.fixture';

// Every case here must be rejected; readOnlyCustomer's teardown proves the wallet was not touched.
test.describe('Purchase validation', { tag: '@regression' }, () => {
  const invalidMsisdns = ['0821234', '08212345678', '0521234567', '+44821234567', '082-123-4567'];
  for (const msisdn of invalidMsisdns) {
    test(`rejects invalid mobile number ${msisdn}`, async ({ api, readOnlyCustomer: customer }) => {
      // Arrange
      const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
      const request = PurchaseRequestBuilder.for(product).withRecipient({ msisdn }).build();

      // Act
      const response = await customer.purchases.create(request);

      // Assert
      expectValidationError(response, 'recipient.msisdn');
    });
  }

  test('rejects a meter number that is not 11 digits', async ({ api, readOnlyCustomer: customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.ELECTRICITY_ESKOM);
    const request = PurchaseRequestBuilder.for(product).withRecipient({ meterNumber: '1234567890' }).build();

    // Act
    const response = await customer.purchases.create(request);

    // Assert
    expectValidationError(response, 'recipient.meterNumber');
  });

  const variableAmountCases = [
    { name: 'below minimum', amount: 400 },
    { name: 'above maximum', amount: 100_100 },
    { name: 'not a multiple of the step', amount: 1_050 },
    { name: 'missing', amount: undefined },
  ];
  for (const { name, amount } of variableAmountCases) {
    test(`rejects a variable-price amount that is ${name}`, async ({ api, readOnlyCustomer: customer }) => {
      // Arrange
      const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
      const request = PurchaseRequestBuilder.for(product).withAmount(amount).build();

      // Act
      const response = await customer.purchases.create(request);

      // Assert
      expectValidationError(response, 'amountCents');
    });
  }

  test('rejects an amount for a fixed-price product', async ({ api, readOnlyCustomer: customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.DATA_VODACOM_1GB);
    const request = PurchaseRequestBuilder.for(product).withAmount(9_900).build();

    // Act
    const response = await customer.purchases.create(request);

    // Assert
    expectValidationError(response, 'amountCents');
  });

  test('rejects an unknown product', async ({ readOnlyCustomer: customer }) => {
    // Arrange
    const request = {
      productId: '00000000-0000-4000-8000-000000000000',
      recipient: { msisdn: Recipients.msisdn() },
      amountCents: 1_000,
    };

    // Act
    const response = await customer.purchases.create(request);

    // Assert
    expectApiError(response, 422, 'PRODUCT_NOT_FOUND');
  });

  test('rejects a purchase the wallet cannot cover', async ({ api, readOnlyCustomer: customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const balance = await customer.balanceCents();
    const request = PurchaseRequestBuilder.for(product)
      .withAmount(balance + 100)
      .build();

    // Act
    const response = await customer.purchases.create(request);

    // Assert
    expectApiError(response, 422, 'INSUFFICIENT_FUNDS');
    expect(expectStatus(await customer.purchases.list(), 200).total).toBe(0);
  });

  test('rejects a request body larger than 32 KB', async ({ api, readOnlyCustomer: customer }) => {
    // Arrange
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const request = { ...PurchaseRequestBuilder.for(product).build(), note: 'x'.repeat(40_000) };

    // Act
    const response = await customer.purchases.create(request);

    // Assert
    expectApiError(response, 413, 'PAYLOAD_TOO_LARGE');
  });
});

test.describe('Purchase funds under concurrency', { tag: ['@regression', '@concurrency'] }, () => {
  test('parallel purchases can never overdraw the wallet', async ({ api, createCustomer }) => {
    // Arrange
    const customer = await createCustomer({ balanceCents: 10_000 });
    const product = await api.products.bySku(Sku.AIRTIME_VODACOM);
    const request = PurchaseRequestBuilder.for(product).withAmount(5_000).build();

    // Act
    const responses = await Promise.all(
      Array.from({ length: 3 }, () => customer.purchases.create({ ...request })),
    );

    // Assert
    expect(responses.map((r) => r.status).sort()).toEqual([202, 202, 422]);
    expect(await customer.balanceCents()).toBe(0);
  });
});

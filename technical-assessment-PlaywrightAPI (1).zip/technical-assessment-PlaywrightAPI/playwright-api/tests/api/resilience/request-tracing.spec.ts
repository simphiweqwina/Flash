import { expectApiError, expectStatus } from '@src/assertions/http';
import { expect, test } from '@src/fixtures/api.fixture';

test.describe('Request tracing and protocol errors', { tag: '@regression' }, () => {
  test('a caller-supplied X-Request-Id is echoed back', async ({ http }) => {
    // Arrange
    const requestId = `trace-${Date.now()}`;

    // Act
    const response = await http.get('/products', { headers: { 'X-Request-Id': requestId } });

    // Assert
    expectStatus(response, 200);
    expect(response.requestId).toBe(requestId);
  });

  test('a request id is generated when the caller supplies an unusable one', async ({ http }) => {
    // Arrange
    const invalidRequestId = 'not valid!';

    // Act
    const response = await http.get('/products', { headers: { 'X-Request-Id': invalidRequestId } });

    // Assert
    expectStatus(response, 200);
    expect(response.requestId).toMatch(/^[0-9a-f-]{36}$/);
  });

  test('malformed JSON is rejected with MALFORMED_JSON', async ({ readOnlyCustomer: customer, http }) => {
    // Arrange
    const headers = { Authorization: `Bearer ${customer.session.accessToken}` };
    const raw = { body: '{"amountCents": 1000', contentType: 'application/json' };

    // Act
    const response = await http.post('/wallet/topups', { headers, raw });

    // Assert
    expectApiError(response, 400, 'MALFORMED_JSON');
  });

  test('non-JSON bodies are rejected with 415', async ({ readOnlyCustomer: customer, http }) => {
    // Arrange
    const headers = { Authorization: `Bearer ${customer.session.accessToken}` };
    const raw = { body: 'amountCents=1000', contentType: 'application/x-www-form-urlencoded' };

    // Act
    const response = await http.post('/wallet/topups', { headers, raw });

    // Assert
    expectApiError(response, 415, 'UNSUPPORTED_MEDIA_TYPE');
  });

  test('a JSON body in an unsupported charset is rejected with 415', async ({
    readOnlyCustomer: customer,
    http,
  }) => {
    // Arrange
    const headers = { Authorization: `Bearer ${customer.session.accessToken}` };
    const raw = { body: '{"amountCents": 1000}', contentType: 'application/json; charset=latin1' };

    // Act
    const response = await http.post('/wallet/topups', { headers, raw });

    // Assert
    expectApiError(response, 415, 'UNSUPPORTED_MEDIA_TYPE');
  });
});

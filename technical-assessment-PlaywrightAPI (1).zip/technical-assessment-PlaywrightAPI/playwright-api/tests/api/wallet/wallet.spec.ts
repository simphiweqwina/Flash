import { expectStatus, expectValidationError } from '@src/assertions/http';
import { expectLedgerToReconcile } from '@src/assertions/ledger';
import { expect, test } from '@src/fixtures/api.fixture';

test.describe('Wallet and top-ups', { tag: '@regression' }, () => {
  test(
    'a top-up credits the wallet and is recorded in the ledger',
    { tag: '@smoke' },
    async ({ customer }) => {
      // Arrange
      const before = await customer.balanceCents();

      // Act
      const response = await customer.account.topUp(2_500);

      // Assert
      const topup = expectStatus(response, 201);
      expect(topup).toMatchObject({ amountCents: 2_500, balanceCents: before + 2_500, currency: 'ZAR' });
      expect(await customer.balanceCents()).toBe(before + 2_500);
      const ledger = await customer.ledger();
      expect(ledger[0]).toMatchObject({
        id: topup.transactionId,
        type: 'TOPUP',
        amountCents: 2_500,
        balanceAfterCents: before + 2_500,
      });
      expectLedgerToReconcile(ledger, before + 2_500);
    },
  );

  for (const amount of [1_000, 500_000]) {
    test(`top-up of ${amount} cents (boundary) is accepted`, async ({ customer }) => {
      // Arrange
      const before = await customer.balanceCents();

      // Act
      const response = await customer.account.topUp(amount);

      // Assert
      expectStatus(response, 201);
      expect(await customer.balanceCents()).toBe(before + amount);
    });
  }

  // readOnlyCustomer's teardown also proves no money moved.
  for (const amount of [999, 500_001, 1_000.5, '1000', null]) {
    test(`top-up of ${JSON.stringify(amount)} cents is rejected`, async ({ readOnlyCustomer }) => {
      // Act
      const response = await readOnlyCustomer.account.topUp(amount);

      // Assert
      expectValidationError(response, 'amountCents');
    });
  }

  test('the ledger can be filtered by entry type', async ({ customer }) => {
    // Arrange
    expectStatus(await customer.account.topUp(1_000), 201);

    // Act
    const response = await customer.account.transactions({ type: 'TOPUP' });

    // Assert
    const page = expectStatus(response, 200);
    expect(page.total).toBe(2); // opening balance + this top-up
    expect(page.items.every((e) => e.type === 'TOPUP')).toBe(true);
  });
});

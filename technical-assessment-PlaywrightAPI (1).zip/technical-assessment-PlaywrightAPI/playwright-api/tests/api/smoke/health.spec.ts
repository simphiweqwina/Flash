import { expectStatus } from '@src/assertions/http';
import { expect, test } from '@src/fixtures/api.fixture';

test.describe('Platform health', { tag: '@smoke' }, () => {
  test('health endpoint reports the service as up', async ({ api }) => {
    // Act
    const response = await api.meta.health();

    // Assert
    const health = expectStatus(response, 200);
    expect(health.status).toBe('ok');
    expect(health.version).not.toBe('');
  });

  test('feature flags are readable and electricity is enabled by default', async ({ api }) => {
    // Act
    const response = await api.meta.features();

    // Assert
    expect(expectStatus(response, 200).electricity).toBe(true);
  });

  test('a signed-in customer can see their profile and balance', async ({ readOnlyCustomer: customer }) => {
    // Act
    const response = await customer.account.me();

    // Assert
    expect(expectStatus(response, 200)).toMatchObject({
      id: customer.user.id,
      username: customer.user.username,
    });
    expect(await customer.balanceCents()).toBe(customer.user.balanceCents);
  });
});

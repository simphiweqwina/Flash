import { expectApiError, expectStatus, expectValidationError } from '@src/assertions/http';
import { Sku } from '@src/data/catalogue';
import { expect, test } from '@src/fixtures/api.fixture';
import type { Product } from '@src/types/api';

const priceOf = (p: Product): number =>
  p.pricing.type === 'FIXED' ? p.pricing.priceCents : p.pricing.minCents;

test.describe('Catalogue', { tag: '@regression' }, () => {
  test('lists only active products, sorted by name by default', { tag: '@smoke' }, async ({ api }) => {
    // Act
    const response = await api.products.list({ pageSize: 50 });

    // Assert
    const page = expectStatus(response, 200);
    expect(page.items).toHaveLength(page.total);
    expect(page.items.every((p) => p.active)).toBe(true);
    expect(page.items.map((p) => p.sku)).not.toContain(Sku.DATA_MTN_LEGACY_INACTIVE);
    const names = page.items.map((p) => p.name);
    expect(names).toEqual([...names].sort((a, b) => a.localeCompare(b)));
  });

  test('pages are disjoint and together cover the whole catalogue', async ({ api }) => {
    // Arrange
    const all = expectStatus(await api.products.list({ pageSize: 50 }), 200);
    const pageSize = 4;
    const expectedPages = Math.ceil(all.total / pageSize);

    // Act
    const pages = await Promise.all(
      Array.from({ length: expectedPages }, (_, i) => api.products.list({ page: i + 1, pageSize })),
    );

    // Assert
    const seen = pages.flatMap((response, i) => {
      const result = expectStatus(response, 200);
      expect(result).toMatchObject({ page: i + 1, pageSize, total: all.total, totalPages: expectedPages });
      return result.items.map((p) => p.id);
    });
    expect(new Set(seen).size).toBe(seen.length);
    expect(seen.sort()).toEqual(all.items.map((p) => p.id).sort());
  });

  test('filters by category and provider (case-insensitive)', async ({ api }) => {
    // Act
    const response = await api.products.list({ category: 'DATA', provider: 'mtn', pageSize: 50 });

    // Assert
    const page = expectStatus(response, 200);
    expect(page.items.length).toBeGreaterThan(0);
    for (const product of page.items) {
      expect(product).toMatchObject({ category: 'DATA', provider: 'MTN' });
    }
  });

  test('sorts by price descending', async ({ api }) => {
    // Act
    const response = await api.products.list({ sort: '-price', pageSize: 50 });

    // Assert
    const prices = expectStatus(response, 200).items.map(priceOf);
    expect(prices).toEqual([...prices].sort((a, b) => b - a));
  });

  test('product detail matches the catalogue entry', async ({ api }) => {
    // Arrange
    const listed = await api.products.bySku(Sku.VOUCHER_GIFT_100);

    // Act
    const response = await api.products.get(listed.id);

    // Assert
    expect(expectStatus(response, 200)).toEqual(listed);
  });

  test('an unknown product id is a 404', async ({ api }) => {
    // Act
    const response = await api.products.get('00000000-0000-4000-8000-000000000000');

    // Assert
    expectApiError(response, 404, 'PRODUCT_NOT_FOUND');
  });

  const invalidQueries = [
    { query: { pageSize: 51 }, field: 'pageSize' },
    { query: { page: 0 }, field: 'page' },
    { query: { category: 'GAMES' }, field: 'category' },
    { query: { sort: 'popularity' }, field: 'sort' },
  ];
  for (const { query, field } of invalidQueries) {
    test(`rejects invalid query parameter: ${JSON.stringify(query)}`, async ({ api }) => {
      // Act
      const response = await api.products.list(query);

      // Assert
      expectValidationError(response, field);
    });
  }
});

import { expectApiError, expectStatus } from '@src/assertions/http';
import { expect, test } from '@src/fixtures/api.fixture';

test.describe('Authentication: session lifecycle', { tag: '@regression' }, () => {
  test('requests without a token are rejected with a Bearer challenge', async ({ http }) => {
    // Act
    const response = await http.get('/wallet');

    // Assert
    expectApiError(response, 401, 'UNAUTHENTICATED');
    expect(response.headers['www-authenticate']).toContain('Bearer');
  });

  test('logout revokes the access token immediately', async ({ customer }) => {
    // Act
    const response = await customer.auth.logout();

    // Assert
    expectStatus(response, 204);
    expectApiError(await customer.account.wallet(), 401, 'INVALID_TOKEN');
  });

  test('an expired access token is rejected', async ({ customer, api }) => {
    // Arrange
    expectStatus(await api.testSupport.expireToken(customer.session.accessToken), 204);

    // Act
    const response = await customer.account.wallet();

    // Assert
    expectApiError(response, 401, 'TOKEN_EXPIRED');
  });

  test('refreshing after expiry issues a new, working token pair', async ({ customer, api }) => {
    // Arrange
    const expiredToken = customer.session.accessToken;
    expectStatus(await api.testSupport.expireToken(expiredToken), 204);

    // Act
    const response = await api.auth.refresh(customer.session.refreshToken);

    // Assert
    const tokens = expectStatus(response, 200);
    expect(tokens.accessToken).not.toBe(expiredToken);
    customer.session.update(tokens);
    expectStatus(await customer.account.wallet(), 200);
  });

  test('a refresh token cannot be used twice (rotation)', async ({ customer, api }) => {
    // Arrange
    const original = customer.session.refreshToken;
    const rotated = expectStatus(await api.auth.refresh(original), 200);

    // Act
    const response = await api.auth.refresh(original);

    // Assert
    expectApiError(response, 401, 'INVALID_REFRESH_TOKEN');
    expect(rotated.refreshToken).not.toBe(original);
  });

  test('a refresh request with a non-JSON body is rejected with 415', async ({ http }) => {
    // Arrange
    const raw = { body: 'refreshToken=abc', contentType: 'text/plain' };

    // Act
    const response = await http.post('/auth/refresh', { raw });

    // Assert
    expectApiError(response, 415, 'UNSUPPORTED_MEDIA_TYPE');
  });
});

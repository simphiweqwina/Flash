import { expectApiError, expectStatus, expectValidationError } from '@src/assertions/http';
import { expect, test } from '@src/fixtures/api.fixture';

test.describe('Authentication: login', { tag: '@regression' }, () => {
  test('valid credentials return a Bearer token pair', { tag: '@smoke' }, async ({ api, createUser }) => {
    // Arrange
    const user = await createUser();

    // Act
    const response = await api.auth.login({ username: user.username, password: user.password });

    // Assert
    const tokens = expectStatus(response, 200);
    expect(tokens.tokenType).toBe('Bearer');
    expect(tokens.expiresIn).toBe(300);
    expect(tokens.accessToken).not.toBe(tokens.refreshToken);
  });

  test('a wrong password is rejected without revealing which field was wrong', async ({
    api,
    createUser,
  }) => {
    // Arrange
    const user = await createUser();

    // Act
    const response = await api.auth.login({ username: user.username, password: `${user.password}x` });

    // Assert
    const error = expectApiError(response, 401, 'INVALID_CREDENTIALS');
    expect(error.message).toBe('Username or password is incorrect.');
  });

  test('a locked account cannot sign in even with the right password', async ({ api, createUser }) => {
    // Arrange
    const user = await createUser({ locked: true });

    // Act
    const response = await api.auth.login({ username: user.username, password: user.password });

    // Assert
    expectApiError(response, 423, 'ACCOUNT_LOCKED');
  });

  const invalidBodies = [
    { name: 'missing username', body: { password: 'secret' }, field: 'username' },
    { name: 'blank username', body: { username: '   ', password: 'secret' }, field: 'username' },
    { name: 'missing password', body: { username: 'someone' }, field: 'password' },
  ];
  for (const { name, body, field } of invalidBodies) {
    test(`login request with ${name} is a validation error`, async ({ api }) => {
      // Act
      const response = await api.auth.login(body);

      // Assert
      expectValidationError(response, field);
    });
  }
});

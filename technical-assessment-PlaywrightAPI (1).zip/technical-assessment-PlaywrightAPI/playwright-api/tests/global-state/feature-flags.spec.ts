import { expectApiError, expectStatus } from '@src/assertions/http';
import { PurchaseRequestBuilder } from '@src/builders/purchase-request.builder';
import { Sku } from '@src/data/catalogue';
import { expect, test } from '@src/fixtures/global-state.fixture';

// Runs on the isolated server only (project "global-state", 1 worker, reset before/after each test).
test.describe('Feature flag: electricity', { tag: '@regression' }, () => {
  test('disabling electricity hides it from the catalogue and blocks purchases', async ({
    api,
    globalState,
    createCustomer,
  }) => {
    // Arrange
    const customer = await createCustomer();
    const electricity = await api.products.bySku(Sku.ELECTRICITY_ESKOM);

    // Act
    const response = await globalState.setFeatures({ electricity: false });

    // Assert
    expect(expectStatus(response, 200)).toEqual({ electricity: false });

    await test.step('flag is visible to clients', async () => {
      expect(expectStatus(await api.meta.features(), 200).electricity).toBe(false);
    });

    await test.step('electricity disappears from the catalogue', async () => {
      const page = expectStatus(await api.products.list({ category: 'ELECTRICITY' }), 200);
      expect(page.total).toBe(0);
      expectApiError(await api.products.get(electricity.id), 404, 'PRODUCT_NOT_FOUND');
    });

    await test.step('purchases are refused and no money moves', async () => {
      expectApiError(
        await customer.purchases.create(PurchaseRequestBuilder.for(electricity).build()),
        422,
        'FEATURE_DISABLED',
      );
      expect(await customer.balanceCents()).toBe(customer.user.balanceCents);
    });
  });

  test('re-enabling electricity restores the catalogue and purchases', async ({
    api,
    globalState,
    createCustomer,
  }) => {
    // Arrange
    const customer = await createCustomer();
    const electricity = await api.products.bySku(Sku.ELECTRICITY_ESKOM);
    expectStatus(await globalState.setFeatures({ electricity: false }), 200);

    // Act
    const response = await globalState.setFeatures({ electricity: true });

    // Assert
    expect(expectStatus(response, 200)).toEqual({ electricity: true });
    expect(expectStatus(await api.products.list({ category: 'ELECTRICITY' }), 200).total).toBeGreaterThan(0);
    const { settled } = await customer.purchaseAndSettle(PurchaseRequestBuilder.for(electricity).build());
    expect(settled.status).toBe('SUCCESSFUL');
  });
});

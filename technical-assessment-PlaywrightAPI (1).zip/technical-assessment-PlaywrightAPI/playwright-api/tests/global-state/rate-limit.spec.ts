import { expectApiError, expectStatus } from '@src/assertions/http';
import { TRANSIENT_ONLY } from '@src/http/retry-policy';
import { expect, test } from '@src/fixtures/global-state.fixture';

const LOGIN_LIMIT_PER_WINDOW = 20;

// Runs on the isolated server only: exhausting the per-IP login budget there cannot starve the main suite.
// TRANSIENT_ONLY: chaos 503s are rejected before the limiter (they don't count), but 429s must surface.
test.describe('Login rate limiting', { tag: '@regression' }, () => {
  test('the 21st login attempt in a window is rejected with Retry-After, even with valid credentials', async ({
    api,
    createUser,
  }) => {
    // Arrange
    const user = await createUser();
    const credentials = { username: user.username, password: user.password };
    const budgetStatuses: number[] = [];
    for (let attempt = 1; attempt <= LOGIN_LIMIT_PER_WINDOW; attempt++) {
      // Failed attempts count too; alternate to prove it.
      const body = attempt % 2 === 0 ? credentials : { ...credentials, password: 'wrong-password' };
      budgetStatuses.push((await api.auth.login(body, TRANSIENT_ONLY)).status);
    }

    // Act
    const response = await api.auth.login(credentials, TRANSIENT_ONLY);

    // Assert
    expect(budgetStatuses, 'the first 20 attempts must be within the limit').not.toContain(429);
    expectApiError(response, 429, 'RATE_LIMITED');
    expect(Number(response.headers['retry-after'])).toBeGreaterThanOrEqual(1);
  });

  test('a reset restores the login budget', async ({ api, globalState, createUser }) => {
    // Arrange
    const user = await createUser();
    for (let attempt = 0; attempt <= LOGIN_LIMIT_PER_WINDOW; attempt++) {
      await api.auth.login({ username: user.username, password: 'wrong-password' }, TRANSIENT_ONLY);
    }
    expectStatus(await globalState.reset(), 204);
    const fresh = await createUser();

    // Act
    const response = await api.auth.login(
      { username: fresh.username, password: fresh.password },
      TRANSIENT_ONLY,
    );

    // Assert
    expectStatus(response, 200);
  });
});

# PayPoint API tests

API test suite for the PayPoint API (`../server`), written with Playwright Test and TypeScript.

## Prerequisites

- Node.js 20 or later (see `../.nvmrc`)
- No browsers are needed; `npx playwright install` is not required.

## Install

```bash
# from the repository root: dependencies of the API under test
npm install

# then the test project
cd playwright-api
npm install
```

## Run

Playwright starts the API, waits for `/health`, runs the tests and stops the API. Do not start the server yourself.

| Command               | What it runs                                              |
| --------------------- | --------------------------------------------------------- |
| `npm test`            | Everything                                                |
| `npm run test:smoke`  | Tests tagged `@smoke`                                     |
| `npm run test:stress` | Parallel suite with 4 workers, each test repeated 3 times |
| `npm run report`      | Opens the last HTML report                                |
| `npm run check`       | Type check, lint and formatting check                     |

Other useful options: `npx playwright test --project=global-state`, `--grep @concurrency`, `--workers=1`.

## Environments

All settings are environment variables; there is nothing to edit in code.

| Variable                | Default             | Purpose                                                                                 |
| ----------------------- | ------------------- | --------------------------------------------------------------------------------------- |
| `API_BASE_URL`          | (unset)             | Test an API that is already running. Playwright then starts nothing.                    |
| `ISOLATED_API_BASE_URL` | (unset)             | Instance for global-state tests. If unset with `API_BASE_URL`, those tests are skipped. |
| `API_PORT`              | `3100`              | Port for the locally started API                                                        |
| `ISOLATED_API_PORT`     | `3101`              | Port for the locally started isolated API                                               |
| `TEST_SUPPORT_KEY`      | `qa-assessment-key` | Value sent as `X-Test-Support-Key`                                                      |
| `REUSE_SERVER`          | `false`             | Reuse an API already listening on `API_PORT`                                            |
| `CI`                    | (unset)             | Forbids `test.only`, uses 4 workers and the GitHub reporter                             |

Examples (PowerShell):

```powershell
# local, default
npm test

# against a deployed environment; global-state tests run only if an isolated instance is provided
$env:API_BASE_URL = "https://staging.example.com"
$env:ISOLATED_API_BASE_URL = "https://staging-isolated.example.com"
npm test
```

Bash: `API_BASE_URL=https://staging.example.com npm test`.

## Reports

- HTML: `reports/html` (`npm run report`)
- JUnit: `reports/junit/results.xml`
- When a test fails, or a request had to be retried, every request and response of that test is attached as `api-exchanges.json` (secrets redacted). Each request carries an `X-Request-Id` that also appears in the server log.

## Layout

```
playwright.config.ts   servers, projects, reporters
src/
  config/env.ts        environment variables
  http/                HttpClient (the only code that sends requests), retry policy
  contracts/           response validation against /openapi.json
  clients/             one client per API area
  actors/customer.ts   a signed-in user with its clients
  fixtures/            Playwright fixtures
  builders/, data/     purchase request builder, SKUs, recipients
  assertions/          status, error and ledger assertions
  utils/polling.ts     bounded polling for asynchronous state
tests/
  api/                 parallel-safe tests (shared server)
  global-state/        feature flags and rate limiting (own server, one worker)
```

Tests follow Arrange / Act / Assert.

## How the suite stays reliable

- **Isolation.** Every test that moves money uses a new user from `POST /__test__/users`. The shared server is never reset.
- **Global state.** Feature-flag, rate-limit and reset tests run in the `global-state` project against a second server, one test at a time, with a reset before and after each test.
- **Login rate limit (20/min per IP).** Tests whose outcome moves no money share one signed-in user per worker (`readOnlyCustomer`). Its balance is checked after every test. Logins that receive `429` wait for `Retry-After`.
- **Transient 503s.** `HttpClient` retries `503` up to 3 times, honouring `Retry-After`; the API documents that these have no side effects. Nothing else is retried, and Playwright test retries are off. Retried requests are annotated in the report.
- **Asynchronous purchases.** Status is polled with a 15 s deadline; there are no fixed sleeps.
- **Contract.** Every response is validated against the OpenAPI document served by the API.

## Known defects

Each defect is covered by a normal test in its functional area that asserts the correct behaviour, so it fails until the defect is fixed:

| Defect                                                                                      | Failing test                                                                                               |
| ------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| A JSON body with an unsupported charset returns `500 INTERNAL_ERROR` instead of `415`.      | `tests/api/resilience/request-tracing.spec.ts`: a JSON body in an unsupported charset is rejected with 415 |
| `POST /auth/refresh` returns `415` for a non-JSON body, but `415` is not documented for it. | `tests/api/auth/session.spec.ts`: a refresh request with a non-JSON body is rejected with 415              |
| Bodies over 32 KB return `413 PAYLOAD_TOO_LARGE`, which no operation documents.             | `tests/api/purchases/validation.spec.ts`: rejects a request body larger than 32 KB                         |

Observations that are not tested as defects:

- The inactive product cannot be found through the public API, so `PRODUCT_UNAVAILABLE` cannot be tested from outside.
- The idempotency check compares the raw body, so `0821234567` and `+27821234567` under the same key give `409`, not a replay.
- Logout revokes the access token only; the refresh token still works.
- The login limit is per IP, so clients behind one proxy share a single budget.

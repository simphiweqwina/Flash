# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tests\api\purchases\validation.spec.ts >> Purchase validation >> rejects a request body larger than 32 KB
- Location: tests\api\purchases\validation.spec.ts:99:7

# Error details

```
ContractViolationError: Response violates the OpenAPI contract (request id pw-7a3a6f-1):
  - POST /purchases -> 413: status is not documented (documented: 200, 202, 400, 401, 409, 415, 422, 503)
Body: {"error":{"code":"PAYLOAD_TOO_LARGE","message":"Request body is too large.","requestId":"pw-7a3a6f-1"}}
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tests\api\auth\session.spec.ts >> Authentication: session lifecycle >> a refresh request with a non-JSON body is rejected with 415
- Location: tests\api\auth\session.spec.ts:62:7

# Error details

```
ContractViolationError: Response violates the OpenAPI contract (request id pw-09190b-1):
  - POST /auth/refresh -> 415: status is not documented (documented: 200, 400, 401, 423, 503)
Body: {"error":{"code":"UNSUPPORTED_MEDIA_TYPE","message":"Request body must be application/json.","requestId":"pw-09190b-1"}}
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tests\api\resilience\request-tracing.spec.ts >> Request tracing and protocol errors >> a JSON body in an unsupported charset is rejected with 415
- Location: tests\api\resilience\request-tracing.spec.ts:53:7

# Error details

```
ContractViolationError: Response violates the OpenAPI contract (request id pw-79213c-1):
  - POST /wallet/topups -> 500: status is not documented (documented: 201, 400, 401, 415, 503)
Body: {"error":{"code":"INTERNAL_ERROR","message":"An unexpected error occurred.","requestId":"pw-79213c-1"}}
```
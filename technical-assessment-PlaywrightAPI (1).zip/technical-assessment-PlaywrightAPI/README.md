# QA Automation Architect – Technical Assessment

Welcome, and thanks for taking the time to do this assessment.

This repository contains **PayPoint API**, a small fictional prepaid-services backend (airtime, data, vouchers and prepaid electricity) built with Express.js. It is the **system under test**.

Your job is to design and build a **Playwright (TypeScript) API test automation project** against it, the kind of foundation you'd be happy for a team of engineers to build on for the next few years.

We care more about **how you think and structure things** than about the number of tests you write. A small, well-built, well-explained suite beats a large, brittle one.

---

## 1. Getting started

**Prerequisites:** Node.js 20 or later (see `.nvmrc`) and npm.

```bash
npm install
npm start            # starts the API on http://localhost:3000
```

Check it's running:

```bash
curl http://localhost:3000/health
```

The full API contract (OpenAPI 3.1) is served at **`GET /openapi.json`**. Read it before you start. You can paste it into any OpenAPI viewer (e.g. editor.swagger.io).

The server keeps all data **in memory**. Restarting it (or calling the reset endpoint) restores the seed data.

---

## 2. The system under test

### 2.1 Domain overview

A user logs in, checks their wallet balance, browses the product catalogue, and buys a product for a recipient (a mobile number, or an electricity meter number). Purchases are **asynchronous**: the wallet is debited immediately, the purchase is `PENDING`, and an upstream provider fulfils it some time later (`SUCCESSFUL`, or `FAILED` with an automatic refund).

All money values are **integers in cents** (ZAR). `10000` = R100.00.

### 2.2 Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/health` | – | Liveness probe |
| GET | `/openapi.json` | – | API contract |
| GET | `/config/features` | – | Current feature flags |
| POST | `/auth/login` | – | Username/password → access + refresh token |
| POST | `/auth/refresh` | – | Rotate tokens (refresh tokens are single-use) |
| POST | `/auth/logout` | Bearer | Revoke the current access token |
| GET | `/products` | – | List active products (paging, filtering, sorting) |
| GET | `/products/{id}` | – | Product detail |
| GET | `/me` | Bearer | Current user profile |
| GET | `/wallet` | Bearer | Wallet balance |
| POST | `/wallet/topups` | Bearer | Add funds |
| GET | `/wallet/transactions` | Bearer | Wallet ledger (newest first) |
| POST | `/purchases` | Bearer + `Idempotency-Key` | Create a purchase (returns `202 PENDING`) |
| GET | `/purchases` | Bearer | List your purchases (newest first) |
| GET | `/purchases/{id}` | Bearer | Purchase detail / status |

Errors always use the same envelope:

```json
{ "error": { "code": "VALIDATION_ERROR", "message": "…", "details": [{ "field": "amountCents", "issue": "…" }], "requestId": "…" } }
```

Every response carries an `X-Request-Id` header. If you send your own `X-Request-Id`, the server echoes it back.

### 2.3 Seed data

| Username | Password | Balance | Notes |
|---|---|---|---|
| `alice` | `Passw0rd!` | R500.00 | Regular user |
| `bob` | `Passw0rd!` | R0.00 | Empty wallet |
| `carol` | `Passw0rd!` | R100.00 | Account is **locked** |

The catalogue has 17 products across `AIRTIME`, `DATA`, `VOUCHER` and `ELECTRICITY`, including one inactive (legacy) product. **Product IDs are regenerated every time the server starts or is reset.** The `sku` is the stable business identifier.

### 2.4 Behaviour you need to know about

These behaviours are deliberate. How you deal with them is a large part of what we're assessing.

| Behaviour | Details |
|---|---|
| **Asynchronous purchases** | `POST /purchases` returns `202` + `PENDING`. Fulfilment takes a random 0.5–4 s. Poll `GET /purchases/{id}` for the outcome. |
| **Provider simulator** | The outcome depends on the recipient (MSISDN or meter number). If it ends in `0000`, the provider rejects it (`FAILED`, `PROVIDER_REJECTED`, wallet refunded). If it ends in `9999`, the provider is slow (about 8 s). Any other ending → `SUCCESSFUL`. |
| **Idempotency** | `Idempotency-Key` (8–64 chars `[A-Za-z0-9_-]`) is required on `POST /purchases`. The same key with the same body replays the original (`200`, `Idempotent-Replayed: true`). The same key with a different body → `409`. Keys are scoped per user. |
| **Short-lived tokens** | Access tokens expire after 5 minutes. Refresh tokens are single-use (rotation). |
| **Login rate limiting** | Max **20 login requests per minute per client IP** (every attempt counts). Exceeding it → `429` with `Retry-After`. |
| **Transient failures** | About **2% of business requests** fail with `503 SERVICE_UNAVAILABLE` and `Retry-After: 1`. A request rejected this way has **no side effects**. `/health`, `/openapi.json` and `/__test__/*` are never affected. |
| **Feature flags** | `electricity` can be switched off. When it's off, electricity products disappear from the catalogue and purchases get `422 FEATURE_DISABLED`. Flags are **global server state**. |
| **Validation** | South African mobile numbers (`0821234567` or `+27821234567`, normalised to E.164). Meter numbers are 11 digits. Variable-priced products have min/max/step rules. Fixed-priced products must **not** receive `amountCents`. |

### 2.5 Test-support endpoints

To make the system testable, the API exposes "backdoor" endpoints that would never ship to production. All of them require the header `X-Test-Support-Key: qa-assessment-key`.

| Method | Path | Purpose |
|---|---|---|
| POST | `/__test__/users` | Create an isolated user with a random username/password. Optional body: `{ "balanceCents": 50000, "locked": false }`. Returns the credentials; you still need to log in. |
| POST | `/__test__/tokens/expire` | `{ "accessToken": "…" }` expires that token immediately |
| PUT | `/__test__/features` | `{ "electricity": false }` toggles a flag (**global**) |
| POST | `/__test__/reset` | Resets **all** state to seed data (**global**: users, tokens, purchases, flags, rate limits) |

Using these endpoints is allowed and encouraged. Think about *which* ones are safe to use and *when*.

### 2.6 Server configuration

The server reads optional environment variables (see `server/config.js`), e.g. `PORT`, `CHAOS_FAILURE_RATE` and `TOKEN_TTL_SECONDS`.

> **Your suite must pass reliably against the default configuration.** You may use different settings for specific, clearly justified purposes, but you must explain why.

---

## 3. Your task

Build a Playwright Test project in **TypeScript** that tests the PayPoint API. Put it in this repository (root-level or a sub-folder, your choice).

### 3.1 Must have

1. **One command to run everything.** From a clean clone, after `npm install` (plus `npx playwright install` if you need it), `npx playwright test` (or an npm script you document) must **start the API automatically**, wait until it's healthy, run the suite and shut the API down. You must not start the server manually.
2. **Meaningful coverage** of the API: happy paths, negative/validation cases, auth/session behaviour, and the asynchronous purchase lifecycle including wallet/ledger consistency. Choose what to cover and explain why (see the write-up).
3. **A maintainable architecture.** For example:
   - a typed API client / service layer, so tests don't hand-build raw HTTP calls everywhere
   - Playwright **fixtures** for setup/teardown and dependency injection
   - test data builders/factories
   - a clear separation between test intent and plumbing
4. **Isolation and parallel safety.** The suite must be green when run with multiple workers, repeatedly, in any order (`--repeat-each`, `--workers`, `--fully-parallel`). No test may depend on another test's side effects.
5. **Determinism.** No fixed sleeps (`waitForTimeout`, `setTimeout`) to wait for state. Handle async behaviour and transient failures deliberately, and explain your retry policy and what it could hide.
6. **Contract validation.** Validate responses against the OpenAPI document (or explain a credible alternative).
7. **Reporting.** A human-friendly report (e.g. Playwright HTML) **and** a machine-readable one suitable for CI (e.g. JUnit). Failures should be easy to diagnose; think about what context gets attached.
8. **A CI pipeline definition** (GitHub Actions, Azure DevOps or GitLab CI, your choice) that installs, runs the suite and publishes the reports and artifacts. It doesn't have to be executed, but it should be correct.
9. **Code quality tooling.** Strict TypeScript, linting and formatting, wired into scripts (and ideally into CI).
10. **A write-up: `SOLUTION.md`** covering:
    - how to run the suite (including any options/tags)
    - your architecture and the main design decisions/trade-offs
    - your test strategy: what you covered, what you deliberately didn't, and why
    - how you handled each behaviour in §2.4
    - any defects, risks, inconsistencies or testability concerns you noticed
    - what you would do next with more time, and how this would scale to many services/teams

### 3.2 Nice to have (pick any, quality over quantity)

- Tagging/grouping (e.g. `@smoke`, `@regression`) with matching scripts or CI stages
- Environment configuration (local / CI / "staging") without code changes
- Custom `expect` matchers, `test.step` for readable reports, meaningful annotations
- Sharding in CI and merged reports
- Data-driven / parameterised tests where they add value
- A small number of concurrency or race-condition tests
- Anything else that shows how you'd set a team up for success

### 3.3 Rules

- **Do not modify anything under `server/`**, except to report findings in `SOLUTION.md`. Treat the API as a black box owned by another team. Reading its source to understand behaviour is fine, but your tests should assert observable behaviour.
- You may add any npm dependencies you need.
- Commit as you go. **We will look at your commit history.**
- Do not publish this repository publicly.

---

## 4. Submission

- Submit either a link to a **private** Git repository (we'll tell you who to grant access to) or a zip of the repository **including the `.git` folder**. Exclude `node_modules`.
- Include the generated HTML report from your final local run (zipped) if you can.

---

## 5. How we assess

| Area | What we look for |
|---|---|
| **Framework architecture** | Layering, abstractions at the right level, fixtures, reuse without over-engineering, typing |
| **Test design & coverage** | Sensible risk-based selection, meaningful assertions, good negative/edge-case thinking |
| **Reliability** | Isolation, parallel safety, handling of async + transient behaviour, no sleeps, honest retry policy |
| **CI/CD & reporting** | One-command runs, pipeline quality, actionable reports and artifacts |
| **Code quality** | Readability, naming, linting/formatting, consistency |
| **Communication** | Clarity of `SOLUTION.md`, quality of reasoning about trade-offs and findings |

After submission, you'll walk us through your solution in a follow-up session (about 60 minutes). We'll ask you to explain decisions, extend something live, and discuss how you'd scale the approach.

Good luck, and enjoy it!
